import { createContext, useContext, useState, ReactNode } from "react";

export type PaymentMethodId = "card";
export type PaymentStatus = "idle" | "pending" | "completed" | "failed";

export interface ShippingData {
  name: string;
  phone: string;
  street: string;
  apartment: string;
  province: string;
  city: string;
  postalCode: string;
  countryCode: string;
}

export interface CardData {
  number: string;
  holder: string;
  expiry: string;
  cvv: string;
  save: boolean;
}

interface CheckoutCtx {
  shipping: ShippingData;
  setShipping: (s: Partial<ShippingData>) => void;
  payment: PaymentMethodId | null;
  setPayment: (p: PaymentMethodId) => void;
  card: CardData;
  setCard: (c: Partial<CardData>) => void;
  reset: () => void;
}

const empty: ShippingData = { name: "", phone: "", street: "", apartment: "", province: "", city: "", postalCode: "", countryCode: "" };
const emptyCard: CardData = { number: "", holder: "", expiry: "", cvv: "", save: true };

const Ctx = createContext<CheckoutCtx | undefined>(undefined);

export const CheckoutProvider = ({ children }: { children: ReactNode }) => {
  const [shipping, setShippingState] = useState<ShippingData>(empty);
  const [payment, setPayment] = useState<PaymentMethodId | null>(null);
  const [card, setCardState] = useState<CardData>(emptyCard);

  return (
    <Ctx.Provider value={{
      shipping,
      setShipping: (s) => setShippingState(prev => ({ ...prev, ...s })),
      payment,
      setPayment,
      card,
      setCard: (c) => setCardState(prev => ({ ...prev, ...c })),
      reset: () => { setShippingState(empty); setPayment(null); setCardState(emptyCard); },
    }}>
      {children}
    </Ctx.Provider>
  );
};

export const useCheckout = () => {
  const c = useContext(Ctx);
  if (!c) throw new Error("useCheckout must be used inside CheckoutProvider");
  return c;
};
