import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import StoreLayout from "@/components/store/StoreLayout";
import { useCart } from "@/contexts/CartContext";
import { useCurrency, COUNTRIES, type Country } from "@/contexts/CurrencyContext";
import { ChevronLeft, ChevronRight, CreditCard, ShieldCheck, Lock, X, Search, Check } from "lucide-react";
import { toast } from "sonner";

type Step = "address" | "gateway" | "stripe" | "paymob";

const Checkout = () => {
  const { items, totalPrice, clearCart } = useCart();
  const { format, country: globalCountry, setCountry: setGlobalCountry } = useCurrency();
  const navigate = useNavigate();
  const [step, setStep] = useState<Step>("address");

  const [country, setCountry] = useState<Country>(globalCountry);
  const [pickerOpen, setPickerOpen] = useState(false);
  const [pickerQ, setPickerQ] = useState("");

  const [shipping, setShipping] = useState({
    name: "", phone: "", street: "", apartment: "", province: "", city: "", postalCode: ""
  });
  const [card, setCard] = useState({ number: "", holder: "", expiry: "", cvv: "", save: true });

  useEffect(() => { setShipping(s => ({ ...s, phone: "" })); }, [country.code]);

  const shippingCost = totalPrice >= 50 ? 0 : 4.99;
  const grandTotal = totalPrice + shippingCost;

  if (items.length === 0) { navigate("/cart"); return null; }

  const handleAddressSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!shipping.name || !shipping.street || !shipping.city || !shipping.phone) {
      toast.error("Please fill in all required fields"); return;
    }
    setGlobalCountry(country);
    setStep("gateway");
  };

  const formatCardNumber = (v: string) => v.replace(/\D/g, "").slice(0, 19).replace(/(.{4})/g, "$1 ").trim();
  const formatExpiry = (v: string) => {
    const d = v.replace(/\D/g, "").slice(0, 4);
    return d.length >= 3 ? `${d.slice(0, 2)}/${d.slice(2)}` : d;
  };

  const handlePay = () => {
    const digits = card.number.replace(/\s/g, "");
    if (digits.length < 13 || !card.holder.trim() || card.expiry.length < 5 || card.cvv.length < 3) {
      toast.error("Please complete all card details"); return;
    }
    toast.success("Processing payment securely...");
    setTimeout(() => {
      clearCart();
      toast.success("Order placed successfully!");
      navigate("/account");
    }, 1500);
  };

  const goBack = () => {
    if (step === "stripe" || step === "paymob") setStep("gateway");
    else if (step === "gateway") setStep("address");
    else navigate(-1);
  };

  const filteredCountries = COUNTRIES.filter(c =>
    c.name.toLowerCase().includes(pickerQ.toLowerCase()) || c.dialCode.includes(pickerQ)
  );

  const headerTitle =
    step === "address" ? "Shipping address"
    : step === "gateway" ? "Choose payment method"
    : step === "stripe" ? "Pay with Stripe"
    : "Pay with Paymob";

  return (
    <StoreLayout hideHeader hideBottomNav>
      <div className="sticky top-0 z-40 bg-white px-4 flex items-center" style={{ height: 48, borderBottom: "1px solid var(--border-soft)" }}>
        <button onClick={goBack}><ChevronLeft className="w-5 h-5 text-[var(--text-1)]" strokeWidth={1.6} /></button>
        <h1 className="text-[14px] font-medium flex-1 text-center text-[var(--text-1)]">{headerTitle}</h1>
        <div className="w-5" />
      </div>

      {step === "address" && (
        <form onSubmit={handleAddressSubmit} className="min-h-screen pb-8" style={{ background: "var(--bg-app)" }}>
          <div className="ux-card mx-4 mt-4 p-4">
            <h3 className="text-[12px] font-medium text-[var(--text-2)] mb-3 uppercase tracking-wide">Country / Region</h3>
            <button type="button" onClick={() => setPickerOpen(true)} className="w-full flex items-center justify-between" style={{ height: 44, border: "1px solid var(--border-soft)", borderRadius: "var(--r-md)", padding: "0 14px" }}>
              <div className="flex items-center gap-2">
                <span className="text-lg">{country.flag}</span>
                <span className="text-[14px] text-[var(--text-1)]">{country.name}</span>
              </div>
              <ChevronRight className="w-4 h-4 text-[var(--text-3)]" />
            </button>
          </div>

          <div className="ux-card mx-4 mt-3 p-4 space-y-3">
            <h3 className="text-[12px] font-medium text-[var(--text-2)] mb-1 uppercase tracking-wide">Personal information</h3>
            <input type="text" value={shipping.name} onChange={e => setShipping(s => ({ ...s, name: e.target.value }))} className="ux-input" placeholder="Contact name" />
            <div className="flex gap-2">
              <input type="tel" value={shipping.phone} onChange={e => setShipping(s => ({ ...s, phone: e.target.value.replace(/\D/g, "") }))} className="ux-input flex-1" placeholder="Phone number" />
              <div className="flex flex-col justify-center px-3" style={{ height: 44, border: "1px solid var(--border-soft)", borderRadius: "var(--r-md)", width: 92 }}>
                <span className="text-[10px] text-[var(--text-3)] leading-none">Code</span>
                <span className="text-[13px] font-medium text-[var(--text-1)] leading-tight" dir="ltr">{country.dialCode}</span>
              </div>
            </div>
          </div>

          <div className="ux-card mx-4 mt-3 p-4 space-y-3">
            <h3 className="text-[12px] font-medium text-[var(--text-2)] mb-1 uppercase tracking-wide">Address</h3>
            <input type="text" value={shipping.street} onChange={e => setShipping(s => ({ ...s, street: e.target.value }))} className="ux-input" placeholder="Street, building, apartment" />
            <input type="text" value={shipping.apartment} onChange={e => setShipping(s => ({ ...s, apartment: e.target.value }))} className="ux-input" placeholder="Apartment, suite, unit (optional)" />
            <input type="text" value={shipping.province} onChange={e => setShipping(s => ({ ...s, province: e.target.value }))} className="ux-input" placeholder="Province / State" />
            <div className="grid grid-cols-2 gap-2">
              <input type="text" value={shipping.city} onChange={e => setShipping(s => ({ ...s, city: e.target.value }))} className="ux-input" placeholder="City" />
              <input type="text" value={shipping.postalCode} onChange={e => setShipping(s => ({ ...s, postalCode: e.target.value }))} className="ux-input" placeholder="Postal code" />
            </div>
          </div>

          <div className="px-4 pt-6">
            <button type="submit" className="ux-btn ux-btn-primary w-full">
              Continue to payment
            </button>
          </div>

          {pickerOpen && (
            <div className="fixed inset-0 z-50 bg-black/40 flex items-end" onClick={() => setPickerOpen(false)}>
              <div onClick={e => e.stopPropagation()} className="bg-white w-full rounded-t-2xl max-h-[85vh] flex flex-col overflow-hidden">
                <div className="flex items-center justify-between px-4 py-3" style={{ borderBottom: "1px solid var(--border-soft)" }}>
                  <h2 className="text-[15px] font-medium text-[var(--text-1)]">Select country</h2>
                  <button type="button" onClick={() => setPickerOpen(false)}><X className="w-5 h-5 text-[var(--text-2)]" /></button>
                </div>
                <div className="px-4 py-3" style={{ borderBottom: "1px solid var(--border-soft)" }}>
                  <div className="flex items-center gap-2 px-3" style={{ height: 40, border: "1px solid var(--border-soft)", borderRadius: 12 }}>
                    <Search className="w-4 h-4 text-[var(--text-3)]" />
                    <input value={pickerQ} onChange={e => setPickerQ(e.target.value)} placeholder="Search country or code..." className="flex-1 bg-transparent text-sm outline-none placeholder:text-[var(--text-3)]" />
                  </div>
                </div>
                <div className="flex-1 overflow-y-auto">
                  {filteredCountries.map(c => (
                    <button type="button" key={c.code} onClick={() => { setCountry(c); setPickerOpen(false); }} className="w-full flex items-center justify-between px-4 py-3 hover:bg-[#fafafa]" style={{ borderBottom: "1px solid #f5f5f5" }}>
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{c.flag}</span>
                        <div className="text-left">
                          <div className="text-sm text-[var(--text-1)]">{c.name}</div>
                          <div className="text-[11px] text-[var(--text-2)]" dir="ltr">{c.dialCode} · {c.currency}</div>
                        </div>
                      </div>
                      {country.code === c.code && <Check className="w-4 h-4 text-[#FF6000]" strokeWidth={2.2} />}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </form>
      )}

      {step === "gateway" && (
        <div className="min-h-screen pb-32" style={{ background: "var(--bg-app)" }}>
          <div className="px-4 pt-4 pb-2 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-[#1B873F]" strokeWidth={1.8} />
            <span className="text-[12px] text-[var(--text-2)]">Choose your payment method</span>
          </div>

          <button onClick={() => setStep("stripe")} className="ux-card w-[calc(100%-32px)] mx-4 mt-2 p-4 flex items-center gap-3">
            <div className="w-9 h-9 rounded-md flex items-center justify-center" style={{ background: "#635BFF" }}>
              <span className="text-white font-semibold text-sm">S</span>
            </div>
            <div className="flex-1 text-left">
              <div className="text-[14px] font-medium text-[var(--text-1)]">Stripe</div>
              <div className="text-[11px] text-[var(--text-2)] mt-0.5">Visa · Mastercard · Amex · JCB</div>
            </div>
            <ChevronRight className="w-4 h-4 text-[var(--text-3)]" />
          </button>

          <button onClick={() => setStep("paymob")} className="ux-card w-[calc(100%-32px)] mx-4 mt-3 p-4 flex items-center gap-3">
            <div className="w-9 h-9 rounded-md flex items-center justify-center" style={{ background: "#0099FF" }}>
              <span className="text-white font-semibold text-sm">P</span>
            </div>
            <div className="flex-1 text-left">
              <div className="text-[14px] font-medium text-[var(--text-1)]">Paymob</div>
              <div className="text-[11px] text-[var(--text-2)] mt-0.5">Local cards · Wallets · Meeza</div>
            </div>
            <ChevronRight className="w-4 h-4 text-[var(--text-3)]" />
          </button>

          <div className="ux-card mx-4 mt-4 p-4">
            <div className="text-[11px] text-[var(--text-2)] uppercase tracking-wide mb-3">Certified secure</div>
            <div className="flex flex-wrap" style={{ gap: 8 }}>
              {["PCI DSS","VISA Secure","MC ID Check","AMEX SafeKey","3D Secure","SSL 256-bit"].map(l => (
                <span key={l} className="text-[10.5px] text-[var(--text-2)] px-2.5 py-1 rounded-md" style={{ border: "1px solid var(--border-soft)", background: "#fafafa" }}>{l}</span>
              ))}
            </div>
          </div>

          <div className="ux-card mx-4 mt-3 p-4">
            <div className="flex justify-between text-[13px] text-[var(--text-2)] py-1"><span>Subtotal</span><span dir="ltr">{format(totalPrice)}</span></div>
            <div className="flex justify-between text-[13px] text-[var(--text-2)] py-1"><span>Shipping</span><span dir="ltr">{shippingCost === 0 ? "Free" : format(shippingCost)}</span></div>
            <div className="flex justify-between text-[14px] font-medium text-[var(--text-1)] pt-2 mt-2" style={{ borderTop: "1px solid var(--border-soft)" }}><span>Total</span><span dir="ltr">{format(grandTotal)}</span></div>
          </div>
        </div>
      )}

      {step === "stripe" && (
        <div className="min-h-screen pb-32" style={{ background: "var(--bg-app)" }}>
          <div className="ux-card mx-4 mt-4 p-4 flex items-center justify-between">
            <div>
              <div className="text-[11px] text-[var(--text-3)] uppercase tracking-wide">Powered by</div>
              <div className="text-[18px] font-semibold tracking-tight" style={{ color: "#635BFF" }}>stripe</div>
            </div>
            <div className="flex items-center gap-1.5 text-[11px] text-[var(--text-2)]">
              <Lock className="w-3.5 h-3.5" /> PCI DSS · 3D Secure 2
            </div>
          </div>

          <div className="ux-card mx-4 mt-3 p-4 space-y-3">
            <div className="text-[11px] text-[var(--text-2)] uppercase tracking-wide">Card information</div>
            <div className="relative">
              <input type="text" inputMode="numeric" value={card.number} onChange={e => setCard(c => ({ ...c, number: formatCardNumber(e.target.value) }))} className="ux-input pr-28" placeholder="1234 1234 1234 1234" />
              <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1">
                <span className="bg-white border border-[var(--border-soft)] rounded px-1.5 py-0.5 text-[8px] font-semibold text-[#1A1F71]">VISA</span>
                <span className="bg-[#EB001B] rounded px-1.5 py-0.5 text-[8px] font-semibold text-white">MC</span>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <input type="text" inputMode="numeric" value={card.expiry} onChange={e => setCard(c => ({ ...c, expiry: formatExpiry(e.target.value) }))} className="ux-input" placeholder="MM / YY" />
              <input type="text" inputMode="numeric" maxLength={4} value={card.cvv} onChange={e => setCard(c => ({ ...c, cvv: e.target.value.replace(/\D/g, "") }))} className="ux-input" placeholder="CVC" />
            </div>
            <input type="text" value={card.holder} onChange={e => setCard(c => ({ ...c, holder: e.target.value }))} className="ux-input" placeholder="Cardholder name" />
            <label className="flex items-center gap-2 cursor-pointer pt-1">
              <input type="checkbox" checked={card.save} onChange={e => setCard(c => ({ ...c, save: e.target.checked }))} className="w-4 h-4 accent-[#FF6000]" />
              <span className="text-[12.5px] text-[var(--text-1)]">Save card for future purchases</span>
            </label>
          </div>

          <div className="ux-card mx-4 mt-3 p-4">
            <div className="flex flex-wrap" style={{ gap: 8 }}>
              {["PCI DSS","VISA Secure","MC ID Check","AMEX SafeKey","3D Secure 2","SSL 256-bit"].map(l => (
                <span key={l} className="text-[10.5px] text-[var(--text-2)] px-2.5 py-1 rounded-md" style={{ border: "1px solid var(--border-soft)", background: "#fafafa" }}>{l}</span>
              ))}
            </div>
          </div>

          <div className="fixed bottom-0 left-0 right-0 z-50 bg-white px-4 py-3" style={{ borderTop: "1px solid var(--border-soft)" }}>
            <button onClick={handlePay} className="ux-btn ux-btn-primary w-full gap-2">
              <Lock className="w-4 h-4" strokeWidth={2} />
              Pay {format(grandTotal)}
            </button>
          </div>
        </div>
      )}

      {step === "paymob" && (
        <div className="min-h-screen pb-32" style={{ background: "var(--bg-app)" }}>
          {/* Compact card preview */}
          <div className="mx-4 mt-4 p-5 text-white relative overflow-hidden" style={{ background: "linear-gradient(135deg,#0099FF 0%,#0066CC 100%)", borderRadius: "var(--r-lg)", aspectRatio: "1.7/1" }}>
            <div className="flex justify-between items-start">
              <div className="w-9 h-6 rounded bg-gradient-to-br from-[#FFD700] to-[#B8860B] opacity-90" />
              <div className="text-[16px] font-semibold italic">paymob</div>
            </div>
            <div className="mt-5">
              <div className="text-[9px] opacity-80 tracking-widest">CARD NUMBER</div>
              <div className="text-[15px] font-mono tracking-wider mt-1">{card.number || "•••• •••• •••• ••••"}</div>
            </div>
            <div className="flex justify-between mt-3">
              <div>
                <div className="text-[8px] opacity-80 tracking-widest">CARD HOLDER</div>
                <div className="text-[11px] uppercase">{card.holder || "YOUR NAME"}</div>
              </div>
              <div>
                <div className="text-[8px] opacity-80 tracking-widest">EXPIRES</div>
                <div className="text-[11px]">{card.expiry || "MM/YY"}</div>
              </div>
            </div>
          </div>

          <div className="ux-card mx-4 mt-3 p-4 space-y-3">
            <div className="relative">
              <input type="text" inputMode="numeric" value={card.number} onChange={e => setCard(c => ({ ...c, number: formatCardNumber(e.target.value) }))} className="ux-input pr-24" placeholder="Card number" />
              <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1">
                <span className="bg-[#E91E63] rounded px-1.5 py-0.5 text-[8px] font-semibold text-white">Meeza</span>
                <span className="bg-white border border-[var(--border-soft)] rounded px-1.5 py-0.5 text-[8px] font-semibold text-[#1A1F71]">VISA</span>
              </div>
            </div>
            <input type="text" value={card.holder} onChange={e => setCard(c => ({ ...c, holder: e.target.value }))} className="ux-input" placeholder="Cardholder name" />
            <div className="grid grid-cols-2 gap-2">
              <input type="text" inputMode="numeric" value={card.expiry} onChange={e => setCard(c => ({ ...c, expiry: formatExpiry(e.target.value) }))} className="ux-input" placeholder="MM/YY" />
              <input type="text" inputMode="numeric" maxLength={4} value={card.cvv} onChange={e => setCard(c => ({ ...c, cvv: e.target.value.replace(/\D/g, "") }))} className="ux-input" placeholder="CVV" />
            </div>
            <label className="flex items-center gap-2 cursor-pointer text-[12.5px] text-[var(--text-1)]">
              <input type="checkbox" checked={card.save} onChange={e => setCard(c => ({ ...c, save: e.target.checked }))} className="w-4 h-4 accent-[#FF6000]" />
              Save card
            </label>
          </div>

          <div className="text-center mt-3 text-[11px] text-[var(--text-2)] flex items-center justify-center gap-1.5">
            <Lock className="w-3 h-3" /> Secured by Paymob
          </div>

          <div className="fixed bottom-0 left-0 right-0 z-50 bg-white px-4 py-3" style={{ borderTop: "1px solid var(--border-soft)" }}>
            <button onClick={handlePay} className="ux-btn ux-btn-primary w-full gap-2">
              <Lock className="w-4 h-4" strokeWidth={2} />
              Pay {format(grandTotal)}
            </button>
          </div>
        </div>
      )}
    </StoreLayout>
  );
};

export default Checkout;
