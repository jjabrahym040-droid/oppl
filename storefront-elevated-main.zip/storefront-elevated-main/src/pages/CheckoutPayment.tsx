import { useState } from "react";
import { useNavigate } from "react-router-dom";
import StoreLayout from "@/components/store/StoreLayout";
import CheckoutHeader from "@/components/store/CheckoutHeader";
import CheckoutLoadingOverlay from "@/components/store/CheckoutLoadingOverlay";
import { useCheckout } from "@/contexts/CheckoutContext";
import { useCart } from "@/contexts/CartContext";
import { useCurrency } from "@/contexts/CurrencyContext";
import { CreditCard, ChevronRight } from "lucide-react";
import { VisaIcon, MastercardIcon, AmexIcon, JcbIcon } from "@/components/store/CardBrands";

const CheckoutPayment = () => {
  const navigate = useNavigate();
  const { items, totalPrice } = useCart();
  const { format } = useCurrency();
  const { payment, setPayment, shipping } = useCheckout();
  const [loading, setLoading] = useState(false);

  if (items.length === 0) { navigate("/cart"); return null; }
  if (!shipping.name) { navigate("/checkout/address"); return null; }

  const choose = () => {
    setPayment("card");
    setLoading(true);
    setTimeout(() => navigate("/checkout/card"), 3000);
  };

  const shippingCost = totalPrice >= 50 ? 0 : 4.99;
  const grandTotal = totalPrice + shippingCost;
  const selected = payment === "card";

  return (
    <StoreLayout hideHeader hideBottomNav>
      <CheckoutHeader title="Add a payment method" onBack={() => navigate("/checkout/address")} />
      <div className="min-h-screen pb-24" style={{ background: "#F7F7F8", fontFamily: "Inter, system-ui, sans-serif" }}>
        <div className="bg-white mt-2 border-y border-[#ECECEC]">
          <button onClick={choose} className="w-full flex items-center gap-3 px-4 py-4 text-left">
            <span className={`w-4 h-4 rounded-full border flex items-center justify-center flex-shrink-0 ${selected ? "border-[#FF6000]" : "border-[#999]"}`}>
              {selected && <span className="w-2 h-2 rounded-full bg-[#FF6000]" />}
            </span>
            <CreditCard className="w-5 h-5 text-[#333]" strokeWidth={1.5} />
            <div className="flex-1 min-w-0">
              <div className="text-[14px] font-medium text-[#111] leading-tight">Credit / Debit Card (Visa/Mastercard)</div>
              <div className="flex items-center gap-1.5 mt-1.5">
                <VisaIcon h={18} /><MastercardIcon h={18} /><AmexIcon h={18} /><JcbIcon h={18} />
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-[#888]" />
          </button>
        </div>

        <div className="bg-white mt-2 px-4 py-3 border-y border-[#ECECEC]">
          <div className="flex justify-between text-[13px] text-[#555] py-1"><span>Subtotal</span><span dir="ltr">{format(totalPrice)}</span></div>
          <div className="flex justify-between text-[13px] text-[#555] py-1"><span>Shipping</span><span dir="ltr">{shippingCost === 0 ? "Free" : format(shippingCost)}</span></div>
          <div className="flex justify-between text-[14px] font-semibold text-[#111] pt-2 mt-2 border-t border-[#ECECEC]"><span>Order total</span><span dir="ltr">{format(grandTotal)}</span></div>
        </div>
      </div>
      {loading && <CheckoutLoadingOverlay label="Verifying payment method..." />}
    </StoreLayout>
  );
};

export default CheckoutPayment;
