import { useState } from "react";
import { useNavigate } from "react-router-dom";
import StoreLayout from "@/components/store/StoreLayout";
import CheckoutHeader from "@/components/store/CheckoutHeader";

import CheckoutLoadingOverlay from "@/components/store/CheckoutLoadingOverlay";
import { useCheckout } from "@/contexts/CheckoutContext";
import { useCurrency, COUNTRIES } from "@/contexts/CurrencyContext";
import { useCart } from "@/contexts/CartContext";
import { ChevronRight, X, Search, Check } from "lucide-react";
import { toast } from "sonner";

const CheckoutAddress = () => {
  const navigate = useNavigate();
  const { items } = useCart();
  const { country: globalCountry, setCountry: setGlobalCountry } = useCurrency();
  const { shipping, setShipping } = useCheckout();
  const [country, setCountry] = useState(COUNTRIES.find(c => c.code === shipping.countryCode) || globalCountry);
  const [pickerOpen, setPickerOpen] = useState(false);
  const [pickerQ, setPickerQ] = useState("");
  const [loading, setLoading] = useState(false);

  if (items.length === 0) { navigate("/cart"); return null; }

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!shipping.name || !shipping.street || !shipping.city || !shipping.phone) {
      toast.error("Please fill in all required fields"); return;
    }
    setGlobalCountry(country);
    setShipping({ countryCode: country.code });
    setLoading(true);
    setTimeout(() => navigate("/checkout/payment"), 3000);
  };

  const filtered = COUNTRIES.filter(c =>
    c.name.toLowerCase().includes(pickerQ.toLowerCase()) || c.dialCode.includes(pickerQ)
  );

  const field = "w-full bg-white border border-[#D5D9D9] rounded-[8px] px-3 text-[14px] text-[#111] placeholder:text-[#888] focus:outline-none focus:border-[#007185] focus:ring-2 focus:ring-[#C7E5EA]";

  return (
    <StoreLayout hideHeader hideBottomNav>
      <CheckoutHeader title="Shipping address" onBack={() => navigate("/cart")} />
      
      <form onSubmit={submit} className="min-h-screen pb-24" style={{ background: "#F7F7F8", fontFamily: "Inter, system-ui, sans-serif" }}>
        <div className="bg-white mt-2 px-4 py-4 border-y border-[#ECECEC]">
          <h3 className="text-[12px] font-medium text-[#555] mb-2 uppercase tracking-wide">Country / Region</h3>
          <button type="button" onClick={() => setPickerOpen(true)} className="w-full flex items-center justify-between border border-[#D5D9D9] rounded-[8px] px-3 h-11">
            <div className="flex items-center gap-2">
              <span className="text-lg">{country.flag}</span>
              <span className="text-[14px] text-[#111]">{country.name}</span>
            </div>
            <ChevronRight className="w-4 h-4 text-[#888]" />
          </button>
        </div>

        <div className="bg-white mt-2 px-4 py-4 border-y border-[#ECECEC] space-y-3">
          <h3 className="text-[12px] font-medium text-[#555] uppercase tracking-wide">Personal information</h3>
          <input type="text" value={shipping.name} onChange={e => setShipping({ name: e.target.value })} className={`${field} h-11`} placeholder="Full name" />
          <div className="flex gap-2">
            <div className="flex flex-col justify-center px-3 border border-[#D5D9D9] rounded-[8px] h-11" style={{ width: 88 }}>
              <span className="text-[10px] text-[#888] leading-none">Code</span>
              <span className="text-[13px] font-medium text-[#111] leading-tight" dir="ltr">{country.dialCode}</span>
            </div>
            <input type="tel" value={shipping.phone} onChange={e => setShipping({ phone: e.target.value.replace(/\D/g, "") })} className={`${field} h-11 flex-1`} placeholder="Phone number" />
          </div>
        </div>

        <div className="bg-white mt-2 px-4 py-4 border-y border-[#ECECEC] space-y-3">
          <h3 className="text-[12px] font-medium text-[#555] uppercase tracking-wide">Address</h3>
          <input type="text" value={shipping.street} onChange={e => setShipping({ street: e.target.value })} className={`${field} h-11`} placeholder="Street, building" />
          <input type="text" value={shipping.apartment} onChange={e => setShipping({ apartment: e.target.value })} className={`${field} h-11`} placeholder="Apartment, suite (optional)" />
          <input type="text" value={shipping.province} onChange={e => setShipping({ province: e.target.value })} className={`${field} h-11`} placeholder="Province / State" />
          <div className="grid grid-cols-2 gap-2">
            <input type="text" value={shipping.city} onChange={e => setShipping({ city: e.target.value })} className={`${field} h-11`} placeholder="City" />
            <input type="text" value={shipping.postalCode} onChange={e => setShipping({ postalCode: e.target.value })} className={`${field} h-11`} placeholder="Postal code" />
          </div>
        </div>

        <div className="px-4 pt-6">
          <button type="submit" className="w-full h-11 rounded-full bg-[#FF6000] text-white text-[14px] font-medium">
            Continue
          </button>
        </div>

        {pickerOpen && (
          <div className="fixed inset-0 z-50 bg-black/40 flex items-end" onClick={() => setPickerOpen(false)}>
            <div onClick={e => e.stopPropagation()} className="bg-white w-full rounded-t-2xl max-h-[85vh] flex flex-col overflow-hidden">
              <div className="flex items-center justify-between px-4 py-3 border-b border-[#ECECEC]">
                <h2 className="text-[15px] font-medium text-[#111]">Select country</h2>
                <button type="button" onClick={() => setPickerOpen(false)}><X className="w-5 h-5 text-[#555]" /></button>
              </div>
              <div className="px-4 py-3 border-b border-[#ECECEC]">
                <div className="flex items-center gap-2 px-3 h-10 border border-[#D5D9D9] rounded-[10px]">
                  <Search className="w-4 h-4 text-[#888]" />
                  <input value={pickerQ} onChange={e => setPickerQ(e.target.value)} placeholder="Search country" className="flex-1 bg-transparent text-sm outline-none" />
                </div>
              </div>
              <div className="flex-1 overflow-y-auto">
                {filtered.map(c => (
                  <button type="button" key={c.code} onClick={() => { setCountry(c); setPickerOpen(false); }} className="w-full flex items-center justify-between px-4 py-3 border-b border-[#f5f5f5]">
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{c.flag}</span>
                      <div className="text-left">
                        <div className="text-sm text-[#111]">{c.name}</div>
                        <div className="text-[11px] text-[#666]" dir="ltr">{c.dialCode} · {c.currency}</div>
                      </div>
                    </div>
                    {country.code === c.code && <Check className="w-4 h-4 text-[#FF6000]" strokeWidth={2.2} />}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </form>
      {loading && <CheckoutLoadingOverlay label="Saving address securely..." />}
    </StoreLayout>
  );
};

export default CheckoutAddress;
