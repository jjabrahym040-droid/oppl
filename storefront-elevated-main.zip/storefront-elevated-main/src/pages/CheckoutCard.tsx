import { useState } from "react";
import { useNavigate } from "react-router-dom";
import StoreLayout from "@/components/store/StoreLayout";
import CheckoutHeader from "@/components/store/CheckoutHeader";

import CheckoutLoadingOverlay from "@/components/store/CheckoutLoadingOverlay";
import { useCheckout } from "@/contexts/CheckoutContext";
import { useCart } from "@/contexts/CartContext";
import { useCurrency } from "@/contexts/CurrencyContext";
import { CreditCard, ShieldCheck, Check } from "lucide-react";
import { CardBrandsRow, VisaIcon, MastercardIcon, AmexIcon, JcbIcon } from "@/components/store/CardBrands";
import { toast } from "sonner";

const CheckoutCard = () => {
  const navigate = useNavigate();
  const { items, totalPrice, clearCart } = useCart();
  const { format } = useCurrency();
  const { card, setCard, shipping } = useCheckout();
  const [loading, setLoading] = useState(false);

  if (items.length === 0) { navigate("/cart"); return null; }
  if (!shipping.name) { navigate("/checkout/address"); return null; }

  const formatCardNumber = (v: string) => v.replace(/\D/g, "").slice(0, 19).replace(/(.{4})/g, "$1 ").trim();
  const formatExpiry = (v: string) => {
    const d = v.replace(/\D/g, "").slice(0, 4);
    return d.length >= 3 ? `${d.slice(0, 2)} / ${d.slice(2)}` : d;
  };

  const shippingCost = totalPrice >= 50 ? 0 : 4.99;
  const grandTotal = totalPrice + shippingCost;

  const submit = () => {
    const digits = card.number.replace(/\s/g, "");
    if (digits.length < 13 || !card.holder.trim() || card.expiry.length < 5 || card.cvv.length < 3) {
      toast.error("Please complete all card details"); return;
    }
    setLoading(true);
    setTimeout(() => {
      clearCart();
      toast.success("Order placed successfully");
      navigate("/account");
    }, 3000);
  };

  const field = "w-full bg-white border border-[#D5D9D9] rounded-[8px] px-3 text-[14px] text-[#111] placeholder:text-[#888] focus:outline-none focus:border-[#007185] focus:ring-2 focus:ring-[#C7E5EA]";

  return (
    <StoreLayout hideHeader hideBottomNav>
      <CheckoutHeader title="Provide further information" onBack={() => navigate("/checkout/payment")} />
      
      <div className="min-h-screen pb-32" style={{ background: "#F7F7F8", fontFamily: "Inter, system-ui, sans-serif" }}>
        <div className="bg-white mt-2 px-4 py-4 border-y border-[#ECECEC]">
          <div className="flex items-center gap-2 mb-3">
            <CreditCard className="w-5 h-5 text-[#333]" strokeWidth={1.6} />
            <span className="text-[15px] font-semibold text-[#111]">Add a new card</span>
          </div>
          <CardBrandsRow h={22} />
        </div>

        <div className="bg-white mt-2 px-4 py-4 border-y border-[#ECECEC] space-y-3">
          <div className="text-[13px] text-[#333]">Card information</div>
          <div className="relative">
            <input type="text" inputMode="numeric" value={card.number} onChange={e => setCard({ number: formatCardNumber(e.target.value) })} className={`${field} h-12 text-[15px] pr-[150px]`} placeholder="1234 1234 1234 1234" />
            <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1 pointer-events-none">
              <VisaIcon h={18} /><MastercardIcon h={18} /><AmexIcon h={18} /><JcbIcon h={18} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <input type="text" inputMode="numeric" value={card.expiry} onChange={e => setCard({ expiry: formatExpiry(e.target.value) })} className={`${field} h-12 text-[15px]`} placeholder="MM / YY" />
            <input type="text" inputMode="numeric" maxLength={4} value={card.cvv} onChange={e => setCard({ cvv: e.target.value.replace(/\D/g, "") })} className={`${field} h-12 text-[15px]`} placeholder="CVC" />
          </div>
          <input type="text" value={card.holder} onChange={e => setCard({ holder: e.target.value })} className={`${field} h-12 text-[15px]`} placeholder="Cardholder name" />
        </div>

        <div className="bg-white mt-2 px-4 py-4 border-y border-[#ECECEC] flex items-center justify-between">
          <span className="text-[14px] text-[#111]">Save card details</span>
          <button onClick={() => setCard({ save: !card.save })} className={`relative w-11 h-6 rounded-full transition-colors ${card.save ? "bg-[#FF6000]" : "bg-[#CCC]"}`}>
            <span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-all ${card.save ? "left-[22px]" : "left-0.5"}`} />
          </button>
        </div>

        <div className="bg-white mt-2 px-4 py-4 border-y border-[#ECECEC]">
          <div className="flex items-center gap-2 mb-3">
            <ShieldCheck className="w-5 h-5 text-[#333]" strokeWidth={1.6} />
            <span className="text-[14px] font-semibold text-[#111]">We protect your payment information</span>
          </div>
          <ul className="space-y-2">
            {[
              "We follow the Payment Card Industry Data Security Standard (PCI DSS)",
              "All information remains secure and uncompromised",
              "All data is encrypted",
              "Your card information will never be mishandled or sold",
            ].map(t => (
              <li key={t} className="flex items-start gap-2 text-[12.5px] text-[#444] leading-snug">
                <Check className="w-4 h-4 text-[#1B873F] flex-shrink-0 mt-0.5" strokeWidth={2.5} />
                <span>{t}</span>
              </li>
            ))}
          </ul>
          <div className="flex flex-wrap gap-2 mt-3 pt-3 border-t border-[#F0F0F0]">
            {["VISA Secure", "ID Check", "SafeKey", "ProtectBuy", "J/Secure"].map(b => (
              <span key={b} className="text-[10px] text-[#555] px-2 py-1 rounded border border-[#D5D9D9] bg-white">{b}</span>
            ))}
          </div>
        </div>

        <div className="fixed bottom-0 left-0 right-0 z-50 bg-white px-4 py-3 border-t border-[#ECECEC]">
          <button onClick={submit} className="w-full h-12 rounded-full bg-[#E53935] text-white text-[15px] font-semibold">
            Save & confirm
          </button>
          <div className="text-center text-[11px] text-[#666] mt-1.5">Total: <span dir="ltr">{format(grandTotal)}</span></div>
        </div>
      </div>
      {loading && <CheckoutLoadingOverlay label="Processing payment securely..." />}
    </StoreLayout>
  );
};

export default CheckoutCard;
