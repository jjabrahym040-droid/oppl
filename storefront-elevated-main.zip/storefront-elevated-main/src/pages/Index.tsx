import { useSearchParams } from "react-router-dom";
import { useMemo } from "react";
import StoreLayout from "@/components/store/StoreLayout";
import ProductListCard from "@/components/store/ProductListCard";
import ProductCardSkeleton from "@/components/store/ProductCardSkeleton";
import { useProducts } from "@/hooks/useProducts";

const Index = () => {
  const { products, loading } = useProducts();
  const [params] = useSearchParams();
  const cat = params.get("cat");

  const filtered = useMemo(
    () => (cat ? products.filter(p => p.category === cat) : products),
    [products, cat]
  );

  return (
    <StoreLayout>
      {loading ? (
        <div className="grid grid-cols-2 p-3" style={{ gap: 12 }}>
          {Array.from({ length: 6 }).map((_, i) => <ProductCardSkeleton key={i} />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-20 px-4">
          <p className="text-[15px] text-[var(--text-1)] mb-1">No products in this category</p>
          <p className="text-[13px] text-[var(--text-2)]">Try another category above</p>
        </div>
      ) : (
        <div className="bg-white">
          {filtered.map(p => (
            <ProductListCard key={p.id} product={p} />
          ))}
        </div>
      )}
    </StoreLayout>
  );
};

export default Index;
