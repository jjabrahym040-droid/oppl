import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import StoreLayout from "@/components/store/StoreLayout";
import { useAuth } from "@/contexts/AuthContext";
import { lovable } from "@/integrations/lovable/index";
import { toast } from "sonner";
import { Mail, ChevronLeft } from "lucide-react";

const Auth = () => {
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [sending, setSending] = useState(false);
  const { user, sendOtp, verifyOtp } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (user) navigate("/account", { replace: true });
  }, [user, navigate]);

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) { toast.error("يرجى إدخال البريد الإلكتروني"); return; }
    setSending(true);
    const res = await sendOtp(email);
    setSending(false);
    if (res.ok) {
      setOtpSent(true);
      toast.success("تم إرسال رمز التأكيد إلى بريدك الإلكتروني");
    } else {
      toast.error(res.error || "حدث خطأ أثناء إرسال رمز التأكيد");
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!otp) { toast.error("يرجى إدخال رمز التأكيد"); return; }
    setSending(true);
    const res = await verifyOtp(email, otp);
    setSending(false);
    if (res.ok) {
      toast.success("تم تسجيل الدخول بنجاح!");
      // navigation handled by useEffect on `user`
    } else {
      toast.error(res.error || "رمز التأكيد غير صحيح");
    }
  };

  const handleGoogleLogin = async () => {
    try {
      const result = await lovable.auth.signInWithOAuth("google", {
        redirect_uri: window.location.origin + "/account",
      });
      if (result.error) {
        toast.error("فشل تسجيل الدخول بـ Google");
        return;
      }
      // Either browser will redirect to Google, or session is set automatically.
      // Don't navigate manually — the useEffect on `user` handles routing.
    } catch {
      toast.error("حدث خطأ أثناء تسجيل الدخول");
    }
  };

  if (user) return null;

  return (
    <StoreLayout hideHeader>
      <div className="bg-white px-4 flex items-center gap-2" style={{ height: 48, borderBottom: "1px solid var(--border-soft)" }}>
        <button onClick={() => navigate(-1)}>
          <ChevronLeft className="w-5 h-5 text-[var(--text-1)]" strokeWidth={1.6} />
        </button>
        <span className="text-[14px] font-medium text-[var(--text-1)]">Sign in</span>
      </div>

      <div className="px-4 py-8 max-w-sm mx-auto">
        <div className="text-center mb-8">
          <span className="text-[28px] font-semibold tracking-tight text-[#0A1F44]">
            ULTRA-X <span className="text-[#E53935]">STORE</span>
          </span>
          <p className="text-[12px] text-[var(--text-2)] mt-1.5">Sign in or create an account to continue</p>
        </div>

        <div className="ux-card p-5">
          {!otpSent ? (
            <form onSubmit={handleSendOtp} className="space-y-4">
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--text-3)]" strokeWidth={1.6} />
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  className="ux-input"
                  style={{ paddingLeft: 38 }}
                  placeholder="Enter your email address"
                />
              </div>
              <p className="text-[11px] text-[var(--text-2)]">A verification code will be sent to your email.</p>
              <button type="submit" disabled={sending} className="ux-btn ux-btn-primary w-full disabled:opacity-50">
                {sending ? "Sending..." : "Send verification code"}
              </button>
            </form>
          ) : (
            <form onSubmit={handleVerifyOtp} className="space-y-4">
              <p className="text-[12px] text-[var(--text-2)] text-center">
                Code sent to <span className="text-[var(--text-1)] font-medium">{email}</span>
              </p>
              <input
                type="text"
                value={otp}
                onChange={e => setOtp(e.target.value)}
                className="ux-input text-center tracking-[0.4em] font-medium"
                placeholder="• • • • • •"
                maxLength={6}
                inputMode="numeric"
              />
              <button type="submit" disabled={sending} className="ux-btn ux-btn-primary w-full disabled:opacity-50">
                {sending ? "Verifying..." : "Verify"}
              </button>
              <button type="button" onClick={() => { setOtpSent(false); setOtp(""); }} className="w-full text-[12px] text-[var(--text-2)] py-1">
                Change email
              </button>
            </form>
          )}

          <div className="flex items-center gap-3 my-5">
            <div className="flex-1 h-px bg-[var(--border-soft)]" />
            <span className="text-[10px] text-[var(--text-3)] uppercase tracking-wider">or</span>
            <div className="flex-1 h-px bg-[var(--border-soft)]" />
          </div>

          <button type="button" onClick={handleGoogleLogin} className="ux-btn ux-btn-secondary w-full gap-2.5">
            <svg width="18" height="18" viewBox="0 0 24 24">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/>
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
            </svg>
            Continue with Google
          </button>
        </div>
      </div>
    </StoreLayout>
  );
};

export default Auth;
