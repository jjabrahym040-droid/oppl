import { Link, useNavigate } from "react-router-dom";
import StoreLayout from "@/components/store/StoreLayout";
import { useCart } from "@/contexts/CartContext";
import { useCurrency } from "@/contexts/CurrencyContext";
import { Minus, Plus, ShoppingBag, ChevronLeft, Check, Search, User } from "lucide-react";
import { useState } from "react";
import ProductCard from "@/components/store/ProductCard";
import { useProducts } from "@/hooks/useProducts";

const Cart = () => {
  const { items, updateQuantity, removeItem, totalPrice, totalItems } = useCart();
  const { format } = useCurrency();
  const { products } = useProducts();
  const navigate = useNavigate();
  const [selectedAll, setSelectedAll] = useState(true);
  const [selectedItems, setSelectedItems] = useState<Set<string>>(new Set(items.map(i => i.product.id)));

  const toggleAll = () => {
    if (selectedAll) {
      setSelectedItems(new Set());
    } else {
      setSelectedItems(new Set(items.map(i => i.product.id)));
    }
    setSelectedAll(!selectedAll);
  };

  const toggleItem = (id: string) => {
    const newSet = new Set(selectedItems);
    if (newSet.has(id)) newSet.delete(id);
    else newSet.add(id);
    setSelectedItems(newSet);
    setSelectedAll(newSet.size === items.length);
  };

  const toggleStore = (storeItems: typeof items) => {
    const ids = storeItems.map(i => i.product.id);
    const allSelected = ids.every(id => selectedItems.has(id));
    const newSet = new Set(selectedItems);
    if (allSelected) {
      ids.forEach(id => newSet.delete(id));
    } else {
      ids.forEach(id => newSet.add(id));
    }
    setSelectedItems(newSet);
    setSelectedAll(newSet.size === items.length);
  };

  const selectedTotal = items
    .filter(i => selectedItems.has(i.product.id))
    .reduce((sum, i) => sum + i.product.price * i.quantity, 0);

  const relatedProducts = products.slice(0, 4);

  if (items.length === 0) {
    return (
      <StoreLayout>
        <div className="text-center py-16">
          <ShoppingBag className="w-12 h-12 mx-auto text-[#ccc] mb-3" strokeWidth={1.5} />
          <h1 className="text-base font-bold mb-2 text-[#191919]">العربة فارغة</h1>
          <p className="text-xs text-[#999] mb-4">أضف بعض المنتجات للبدء في التسوق</p>
          <Link to="/products" className="text-sm font-bold px-6 py-2.5 rounded-full text-white inline-block" style={{ backgroundColor: '#E53935' }}>تسوق الآن</Link>
        </div>
      </StoreLayout>
    );
  }

  const grouped = items.reduce((acc, item) => {
    const store = item.product.store;
    if (!acc[store]) acc[store] = [];
    acc[store].push(item);
    return acc;
  }, {} as Record<string, typeof items>);

  const Checkbox = ({ checked, onClick }: { checked: boolean; onClick: () => void }) => (
    <button onClick={onClick} className={`w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-colors ${checked ? 'border-transparent' : 'border-[#ccc]'}`} style={checked ? { backgroundColor: '#E53935' } : {}}>
      {checked && <Check className="w-3 h-3 text-white" strokeWidth={2.5} />}
    </button>
  );

  return (
    <StoreLayout hideHeader>
      {/* Cart header */}
      <div className="sticky top-0 z-50 bg-white px-3 py-2.5 flex items-center justify-between border-b border-[#eee]">
        <div className="flex items-center gap-3">
          <Search className="w-5 h-5 text-[#191919]" strokeWidth={1.5} />
          <Link to="/account">
            <User className="w-5 h-5 text-[#191919]" strokeWidth={1.5} />
          </Link>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-lg font-black">
            <span style={{ color: '#E53935' }}>Ali</span>
            <span className="text-[#191919]">Express</span>
          </span>
          <span className="text-[#191919]">≡</span>
          <button onClick={() => navigate(-1)}>
            <ChevronLeft className="w-5 h-5 text-[#191919] rotate-180" strokeWidth={1.5} />
          </button>
        </div>
      </div>

      {/* Cart title */}
      <div className="bg-white px-3 py-2 border-b border-[#f0f0f0]">
        <h1 className="text-base font-bold text-right text-[#191919]">العربة ({totalItems})</h1>
      </div>

      {/* Select all */}
      <div className="bg-white px-3 py-2.5 border-b border-[#f0f0f0] flex items-center justify-between">
        <button className="text-xs text-[#999]">حذف</button>
        <button onClick={toggleAll} className="flex items-center gap-2">
          <span className="text-xs font-medium text-[#191919]">تحديد كل المنتجات</span>
          <Checkbox checked={selectedAll} onClick={toggleAll} />
        </button>
      </div>

      {/* Grouped items */}
      <div className="space-y-2 p-2">
        {Object.entries(grouped).map(([store, storeItems]) => {
          const allStoreSelected = storeItems.every(i => selectedItems.has(i.product.id));
          return (
            <div key={store} className="bg-white rounded-2xl overflow-hidden">
              <div className="px-3 py-1.5 text-[10px] flex items-center justify-end gap-1" style={{ backgroundColor: '#E8F5E9', color: '#2E7D32' }}>
                يتم الشحن عبر البائعين الدوليين ✓
              </div>
              <div className="px-3 py-2.5 border-b border-[#f0f0f0] flex items-center justify-end gap-2">
                <span className="text-xs font-bold text-[#191919]">{store}</span>
                <Checkbox checked={allStoreSelected} onClick={() => toggleStore(storeItems)} />
              </div>
              {storeItems.map(item => {
                const disc = item.product.originalPrice
                  ? Math.round(((item.product.originalPrice - item.product.price) / item.product.originalPrice) * 100)
                  : 0;
                return (
                  <div key={item.product.id} className="px-3 py-3 flex gap-2.5 border-b border-[#f5f5f5]">
                    <div className="flex-1 min-w-0">
                      {item.product.isSuperDeal && (
                        <span className="text-[9px] font-bold text-white px-1.5 py-0.5 rounded" style={{ backgroundColor: '#E53935' }}>عرض</span>
                      )}
                      <Link to={`/product/${item.product.id}`} className="text-[11px] text-[#191919] line-clamp-2 leading-relaxed block mt-0.5">
                        {item.product.name}
                      </Link>
                      <div className="mt-1.5">
                        <span className="text-sm font-black" style={{ color: '#E53935' }}>{format(item.product.price * item.quantity)}</span>
                      </div>
                      {item.product.originalPrice && (
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] text-[#999] line-through font-bold">{format(item.product.originalPrice)}</span>
                          {disc > 0 && (
                            <span className="text-[10px] px-1.5 py-0.5 rounded font-medium" style={{ backgroundColor: '#FFF0F0', color: '#E53935' }}>العرض -{disc}% الآن</span>
                          )}
                        </div>
                      )}
                      <div className="flex items-center gap-0 mt-2 border border-[#ddd] rounded-xl w-fit overflow-hidden">
                        <button onClick={() => updateQuantity(item.product.id, item.quantity + 1)} className="px-2.5 py-1.5">
                          <Plus className="w-3 h-3 text-[#191919]" strokeWidth={1.5} />
                        </button>
                        <span className="px-3 text-xs font-semibold text-[#191919]">{item.quantity}</span>
                        <button onClick={() => updateQuantity(item.product.id, item.quantity - 1)} className="px-2.5 py-1.5">
                          <Minus className="w-3 h-3 text-[#191919]" strokeWidth={1.5} />
                        </button>
                      </div>
                    </div>
                    <Link to={`/product/${item.product.id}`} className="w-20 h-20 flex-shrink-0 rounded-xl overflow-hidden bg-[#f5f5f5] relative">
                      <img src={item.product.image} alt={item.product.name} className="w-full h-full object-cover" />
                      {item.product.stockCount <= 5 && (
                        <div className="absolute bottom-0 left-0 right-0 text-[8px] text-center text-white py-0.5 bg-black/60">يتبقى {item.product.stockCount} فقط</div>
                      )}
                    </Link>
                    <Checkbox checked={selectedItems.has(item.product.id)} onClick={() => toggleItem(item.product.id)} />
                  </div>
                );
              })}
            </div>
          );
        })}
      </div>

      {/* Related */}
      <section className="py-4 bg-[#f5f5f5]">
        <h2 className="text-sm font-bold mb-3 px-3 text-right text-[#191919]">مزيد من المحبوب</h2>
        <div className="grid grid-cols-2 gap-[1px] bg-[#f0f0f0]">
          {relatedProducts.map(p => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      {/* Floating checkout bar - sits above bottom nav (which is 56px tall) */}
      <div className="fixed left-0 right-0 z-40 bg-white border-t border-[#eee] px-3 py-2.5 flex items-center justify-between" style={{ bottom: 56 }}>
        <Link
          to="/checkout"
          className="px-6 py-3 rounded-full text-sm font-bold text-white"
          style={{ backgroundColor: '#0B0B0B' }}
        >
          <div className="flex flex-col items-center">
            <span>Checkout ({selectedItems.size})</span>
          </div>
        </Link>
        <div className="flex items-center gap-1.5">
          <span className="text-lg font-black text-[#0B0B0B]" dir="ltr">{format(selectedTotal)}</span>
        </div>
      </div>
    </StoreLayout>
  );
};

export default Cart;
