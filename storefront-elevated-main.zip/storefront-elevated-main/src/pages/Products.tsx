import { useSearchParams, Link } from "react-router-dom";
import StoreLayout from "@/components/store/StoreLayout";
import ProductCard from "@/components/store/ProductCard";
import ProductCardSkeleton from "@/components/store/ProductCardSkeleton";
import { useProducts, useCategories } from "@/hooks/useProducts";
import { useMemo, useState, useRef } from "react";
import { Search } from "lucide-react";

const Products = () => {
  const [searchParams] = useSearchParams();
  const searchQuery = searchParams.get("search") || "";
  const categoryFilter = searchParams.get("category") || "";
  const [selectedCat, setSelectedCat] = useState<string | null>(categoryFilter || null);
  const contentRef = useRef<HTMLDivElement>(null);
  const { products, loading } = useProducts();
  const categories = useCategories();

  const filtered = useMemo(() => {
    let result = [...products];
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(p => p.name.toLowerCase().includes(q) || p.description.toLowerCase().includes(q) || p.brand.toLowerCase().includes(q));
    }
    const cat = selectedCat || categoryFilter;
    if (cat) result = result.filter(p => p.category === cat);
    return result;
  }, [searchQuery, categoryFilter, selectedCat, products]);

  // Get subcategory images for selected category
  const categoryProducts = useMemo(() => {
    const cat = selectedCat || categoryFilter;
    if (!cat) return products.slice(0, 9);
    return products.filter(p => p.category === cat).slice(0, 9);
  }, [selectedCat, categoryFilter, products]);

  return (
    <StoreLayout>
      {/* Slim top bar */}
      <div className="bg-white px-3 py-1.5 flex items-center justify-between border-b border-[#eee]">
        <span className="text-sm font-semibold tracking-tight text-[#0A1F44]">
          ULTRA-X <span className="text-[#E53935]">STORE</span>
        </span>
        <Search className="w-4 h-4 text-[#191919]" strokeWidth={1.5} />
      </div>

      {/* Dual-scroll layout — sidebar on LEFT */}
      <div className="flex" style={{ height: 'calc(100vh - 110px)' }} dir="ltr">
        {/* LEFT sidebar - categories */}
        <div
          className="w-[84px] flex-shrink-0 bg-white overflow-y-auto hide-scrollbar border-r border-[#f0f0f0]"
          style={{ overscrollBehavior: 'contain' }}
        >
          <button
            onClick={() => setSelectedCat(null)}
            className={`w-full py-3 px-2 text-[11px] font-medium text-center transition-colors ${!selectedCat ? 'bg-white border-l-2' : 'text-[#666]'}`}
            style={!selectedCat ? { color: '#E53935', borderLeftColor: '#E53935' } : {}}
          >
            All
          </button>
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setSelectedCat(cat.id)}
              className={`w-full py-3 px-2 text-[11px] font-medium text-center transition-colors ${selectedCat === cat.id ? 'bg-white border-l-2' : 'text-[#666]'}`}
              style={selectedCat === cat.id ? { color: '#E53935', borderLeftColor: '#E53935' } : {}}
            >
              {cat.name}
            </button>
          ))}
        </div>

        {/* RIGHT content area */}
        <div
          ref={contentRef}
          className="flex-1 overflow-y-auto bg-white"
          style={{ overscrollBehavior: 'contain' }}
        >
          <div className="px-3 py-2.5">
            <h2 className="text-sm font-semibold text-[#0B0B0B]">
              {selectedCat ? categories.find(c => c.id === selectedCat)?.name : 'Recommended'}
            </h2>
          </div>

          {!searchQuery && (
            <div className="grid grid-cols-3 gap-2 px-3 pb-3">
              {categoryProducts.map(p => (
                <Link key={p.id} to={`/product/${p.id}`} className="flex flex-col items-center gap-1.5">
                  <div className="w-full aspect-square rounded-md overflow-hidden bg-[#f5f5f5]">
                    <img src={p.image} alt={p.name} className="w-full h-full object-cover" />
                  </div>
                  <span className="text-[10px] text-center text-[#333] leading-tight font-normal line-clamp-1">
                    {p.name.split(' ').slice(0, 2).join(' ')}
                  </span>
                </Link>
              ))}
            </div>
          )}

          <div className="text-center py-2 border-t border-[#f0f0f0]">
            <span className="text-[11px] font-medium text-[#0B0B0B] bg-[#f5f5f5] px-3 py-1 rounded-full border border-[#eee]">For You</span>
          </div>

          <div className="pb-3">
            {loading ? (
              <div className="grid grid-cols-2 gap-2 p-2">
                {Array.from({ length: 6 }).map((_, i) => <ProductCardSkeleton key={i} />)}
              </div>
            ) : filtered.length === 0 ? (
              <div className="text-center py-16 text-[#999]">
                <p className="text-sm">No products found</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 px-3 py-3 bg-white" style={{ columnGap: 10, rowGap: 20 }}>
                {filtered.map(p => (
                  <ProductCard key={p.id} product={p} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </StoreLayout>
  );
};

export default Products;
