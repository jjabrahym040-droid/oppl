import { useParams, Link, useNavigate } from "react-router-dom";
import StoreLayout from "@/components/store/StoreLayout";
import { useProduct, useProducts } from "@/hooks/useProducts";
import { useCart } from "@/contexts/CartContext";
import { useCurrency } from "@/contexts/CurrencyContext";
import { Star, Truck, Minus, Plus, ChevronLeft, Share2, RotateCcw, ShieldCheck, ShoppingCart, ThumbsUp } from "lucide-react";
import { useState, useMemo, useEffect } from "react";
import { toast } from "sonner";
import ProductCard from "@/components/store/ProductCard";
import shippingPromise from "@/assets/shipping-promise.jpg";

// Deterministic seeded data per product so it stays the same across reloads
const FAKE_REVIEWS = [
  { name: "Carlos M.", country: "🇧🇷 Brazil",     text: "Amazing quality, exactly as described. Fast worldwide shipping!" },
  { name: "Akira T.",  country: "🇯🇵 Japan",      text: "Great product, packaging was perfect. Will buy again." },
  { name: "Hannah K.", country: "🇩🇪 Germany",    text: "Best price I found online. Item arrived earlier than expected." },
  { name: "Mohammed A.", country: "🇸🇦 Saudi Arabia", text: "ممتاز جداً، الجودة عالية والشحن سريع. أنصح به." },
  { name: "Lucia R.",  country: "🇪🇸 Spain",      text: "Love it! Exactly what I needed. 5 stars." },
  { name: "John P.",   country: "🇺🇸 USA",        text: "Solid build, works as advertised. Shipping was quick." },
  { name: "Sophie L.", country: "🇫🇷 France",     text: "Très bon produit, livraison rapide. Je recommande." },
];

const seededReviewCount = (id: string) => {
  // Map the uuid into a stable big number between 18,000 and 32,000
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0;
  return 18000 + (h % 14000);
};

const ProductDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { product, loading } = useProduct(id);
  const { products: allProducts } = useProducts();
  const { addItem } = useCart();
  const { format, country } = useCurrency();
  const [quantity, setQuantity] = useState(1);
  const [selectedImage, setSelectedImage] = useState(0);

  // Reset scroll & state when navigating to a new product (deep linking from related items)
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
    setQuantity(1);
    setSelectedImage(0);
  }, [id]);

  const displayRating = product ? Math.max(Number(product.rating) || 0, 4.9) : 4.9;
  const displayReviewCount = useMemo(
    () => (product ? Math.max(product.reviewCount || 0, seededReviewCount(product.id)) : 0),
    [product]
  );

  if (loading) {
    return <StoreLayout><div className="text-center py-16 text-sm">Loading...</div></StoreLayout>;
  }

  if (!product) {
    return (
      <StoreLayout>
        <div className="text-center py-16">
          <h1 className="text-base font-medium">Product not found</h1>
          <Link to="/products" className="text-sm mt-2 inline-block text-[#0A1F44]">Back to products</Link>
        </div>
      </StoreLayout>
    );
  }

  const moreProducts = allProducts.filter(p => p.id !== product.id).slice(0, 8);

  const handleAddToCart = () => {
    addItem(product, quantity);
    toast.success("Added to cart");
  };

  const handleBuyNow = () => {
    addItem(product, quantity);
    navigate("/checkout");
  };

  return (
    <StoreLayout hideHeader hideBottomNav>
      {/* Top nav */}
      <div className="sticky top-0 z-50 bg-white px-3 py-2.5 flex items-center justify-between border-b border-[#eee]">
        <button onClick={() => navigate(-1)}>
          <ChevronLeft className="w-5 h-5 text-[#222]" strokeWidth={2} />
        </button>
        <span className="text-base font-semibold text-[#0B0B0B]">ULTRA-X <span className="text-[#0A1F44]">STORE</span></span>
        <div className="flex items-center gap-3">
          <Share2 className="w-5 h-5 text-[#222]" strokeWidth={1.8} />
          <Link to="/cart"><ShoppingCart className="w-5 h-5 text-[#222]" strokeWidth={1.8} /></Link>
        </div>
      </div>

      {/* Main image */}
      <div className="relative bg-white">
        <div className="aspect-square overflow-hidden">
          <img src={product.images[selectedImage] || product.image} alt={product.name} className="w-full h-full object-cover" />
        </div>
        {product.images.length > 1 && (
          <div className="flex gap-2 px-3 py-2 bg-white overflow-x-auto hide-scrollbar">
            {product.images.map((img, i) => (
              <button key={i} onClick={() => setSelectedImage(i)}
                className={`w-14 h-14 rounded-md border-2 overflow-hidden flex-shrink-0 ${selectedImage === i ? 'border-[#0A1F44]' : 'border-[#eee]'}`}>
                <img src={img} alt="" className="w-full h-full object-cover" />
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Price + name + rating */}
      <div className="bg-white px-4 py-4 border-b border-[#eee]">
        <div className="text-[30px] font-semibold text-[#0B0B0B] leading-none" dir="ltr">
          {format(product.price)}
        </div>
        {country.taxRate > 0 && (
          <div className="text-[11px] text-[#888] mt-1">Includes {country.taxRate}% tax</div>
        )}
        <h1 className="text-[15px] font-normal text-[#222] leading-relaxed mt-3">{product.name}</h1>

        {/* Massive social proof */}
        <div className="flex items-center gap-2 mt-3">
          <div className="flex items-center gap-0.5">
            {[1,2,3,4,5].map(i => (
              <Star key={i} className="w-4 h-4 fill-[#FFB800] text-[#FFB800]" strokeWidth={0} />
            ))}
          </div>
          <span className="text-[13px] font-semibold text-[#0B0B0B]">{displayRating.toFixed(1)}</span>
          <span className="text-[12px] text-[#0A1F44] font-medium">
            +{displayReviewCount.toLocaleString("en-US")} Ratings
          </span>
        </div>
      </div>

      {/* Quantity */}
      <div className="bg-white px-4 py-3 border-b border-[#eee] flex items-center justify-between">
        <span className="text-sm text-[#222]">Quantity</span>
        <div className="flex items-center border border-[#ddd] rounded-md overflow-hidden">
          <button onClick={() => setQuantity(q => Math.max(1, q - 1))} className="px-3 py-1.5">
            <Minus className="w-3.5 h-3.5 text-[#222]" strokeWidth={2} />
          </button>
          <span className="px-4 text-sm text-[#222]">{quantity}</span>
          <button onClick={() => setQuantity(q => q + 1)} className="px-3 py-1.5">
            <Plus className="w-3.5 h-3.5 text-[#222]" strokeWidth={2} />
          </button>
        </div>
      </div>

      {/* Service rows */}
      <div className="bg-white px-4 py-3 border-b border-[#eee] divide-y divide-[#f5f5f5]">
        <div className="flex items-center gap-3 py-2.5">
          <Truck className="w-4 h-4 text-[#0A1F44]" strokeWidth={1.8} />
          <span className="text-[13px] text-[#222]">Worldwide shipping to {country.name}</span>
        </div>
        <div className="flex items-center gap-3 py-2.5">
          <ShieldCheck className="w-4 h-4 text-[#0A1F44]" strokeWidth={1.8} />
          <span className="text-[13px] text-[#222]">Secure payment & buyer protection</span>
        </div>
        <div className="flex items-center gap-3 py-2.5">
          <RotateCcw className="w-4 h-4 text-[#0A1F44]" strokeWidth={1.8} />
          <span className="text-[13px] text-[#222]">30-day return & refund policy</span>
        </div>
      </div>

      {/* Description */}
      {product.description && (
        <div className="bg-white px-4 py-4 border-b border-[#eee]">
          <h3 className="text-sm font-semibold mb-2 text-[#0B0B0B]">Description</h3>
          <p className="text-[13px] text-[#444] leading-relaxed whitespace-pre-line">{product.description}</p>
        </div>
      )}

      {/* Additional product images (gallery as full-width tiles) */}
      {product.images.length > 1 && (
        <div className="bg-white border-b border-[#eee]">
          <div className="px-4 py-3">
            <h3 className="text-sm font-semibold text-[#0B0B0B]">Product gallery</h3>
          </div>
          <div className="space-y-1">
            {product.images.slice(1).map((img, i) => (
              <img key={i} src={img} alt="" className="w-full h-auto object-cover" />
            ))}
          </div>
        </div>
      )}

      {/* International shipping promise image */}
      <div className="bg-white border-b border-[#eee]">
        <div className="px-4 py-3 flex items-center gap-2">
          <Truck className="w-4 h-4 text-[#0A1F44]" strokeWidth={2} />
          <h3 className="text-sm font-semibold text-[#0B0B0B]">International Shipping Guarantee</h3>
        </div>
        <img src={shippingPromise} alt="Worldwide shipping by air, sea and road" className="w-full h-auto object-contain" />
      </div>

      {/* Customer reviews */}
      <div className="bg-white border-b border-[#eee]">
        <div className="px-4 py-3 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-[#0B0B0B]">Customer Reviews</h3>
          <span className="text-[12px] text-[#666]">+{displayReviewCount.toLocaleString("en-US")}</span>
        </div>
        <div className="divide-y divide-[#f5f5f5]">
          {FAKE_REVIEWS.map((r, i) => (
            <div key={i} className="px-4 py-3">
              <div className="flex items-center justify-between">
                <span className="text-[13px] font-semibold text-[#0B0B0B]">{r.name}</span>
                <div className="flex items-center gap-0.5">
                  {[1,2,3,4,5].map(s => (
                    <Star key={s} className="w-3 h-3 fill-[#FFB800] text-[#FFB800]" strokeWidth={0} />
                  ))}
                </div>
              </div>
              <div className="text-[11px] text-[#888] mt-0.5">{r.country}</div>
              <p className="text-[12px] text-[#333] mt-1.5 leading-relaxed">{r.text}</p>
              <div className="flex items-center gap-1 mt-1.5 text-[11px] text-[#888]">
                <ThumbsUp className="w-3 h-3" strokeWidth={1.5} />
                <span>Helpful</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* More products */}
      {moreProducts.length > 0 && (
        <section className="mt-2">
          <div className="px-4 py-3 bg-white border-b border-[#eee]">
            <h2 className="text-sm font-semibold text-[#0B0B0B]">You may also like</h2>
          </div>
          <div className="grid grid-cols-2">
            {moreProducts.map(p => (
              <div key={p.id} className="border-r border-b border-[#f0f0f0]">
                <ProductCard product={p} />
              </div>
            ))}
          </div>
        </section>
      )}

      <div style={{ height: 80 }} />

      {/* Bottom action bar */}
      <div className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-[#eee] px-3 py-2 flex items-center gap-2">
        <button
          onClick={handleAddToCart}
          className="flex-1 py-3.5 rounded-md text-[15px] font-semibold border border-[#0B0B0B] text-[#0B0B0B] bg-white"
        >
          Add to Cart
        </button>
        <button
          onClick={handleBuyNow}
          className="flex-1 py-3.5 rounded-md text-[15px] font-semibold text-white bg-[#0B0B0B]"
        >
          Buy Now
        </button>
      </div>
    </StoreLayout>
  );
};

export default ProductDetail;
