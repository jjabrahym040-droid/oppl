import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import StoreLayout from "@/components/store/StoreLayout";
import { useAuth } from "@/contexts/AuthContext";
import { Globe, DollarSign, Shield, ChevronLeft } from "lucide-react";

const countries = [
  { code: "EG", name: "مصر", flag: "🇪🇬" },
  { code: "SA", name: "السعودية", flag: "🇸🇦" },
  { code: "AE", name: "الإمارات", flag: "🇦🇪" },
  { code: "US", name: "الولايات المتحدة", flag: "🇺🇸" },
];

const currencies = [
  { code: "EGP", name: "جنيه مصري", symbol: "ج.م" },
  { code: "SAR", name: "ريال سعودي", symbol: "ر.س" },
  { code: "USD", name: "دولار أمريكي", symbol: "$" },
];

const ADMIN_EMAIL = "abrahymjrhy391@gmail.com";

const Settings = () => {
  const { user } = useAuth();
  const [country, setCountry] = useState("EG");
  const [currency, setCurrency] = useState("EGP");
  const isAdmin = user?.email === ADMIN_EMAIL;

  return (
    <StoreLayout>
      <div className="px-3 py-4 max-w-lg mx-auto space-y-3">
        <h1 className="text-base font-bold mb-3">الإعدادات</h1>

        <div className="bg-card rounded-lg border border-border p-4">
          <div className="flex items-center gap-2 mb-2">
            <Globe className="w-4 h-4 text-muted-foreground" />
            <h2 className="text-sm font-semibold">البلد</h2>
          </div>
          <select value={country} onChange={e => setCountry(e.target.value)}
            className="w-full px-3 py-2 border border-input rounded-lg bg-background text-sm">
            {countries.map(c => <option key={c.code} value={c.code}>{c.flag} {c.name}</option>)}
          </select>
        </div>

        <div className="bg-card rounded-lg border border-border p-4">
          <div className="flex items-center gap-2 mb-2">
            <DollarSign className="w-4 h-4 text-muted-foreground" />
            <h2 className="text-sm font-semibold">العملة</h2>
          </div>
          <select value={currency} onChange={e => setCurrency(e.target.value)}
            className="w-full px-3 py-2 border border-input rounded-lg bg-background text-sm">
            {currencies.map(c => <option key={c.code} value={c.code}>{c.symbol} - {c.name}</option>)}
          </select>
        </div>

        {isAdmin && (
          <Link to="/admin" className="flex items-center justify-between bg-card rounded-lg border border-border p-4">
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4" style={{ color: '#FF4747' }} />
              <span className="text-sm font-semibold">لوحة تحكم الإدارة</span>
            </div>
            <ChevronLeft className="w-4 h-4 text-muted-foreground" />
          </Link>
        )}
      </div>
    </StoreLayout>
  );
};

export default Settings;
