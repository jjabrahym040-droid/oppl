import AdminLayout from "@/components/admin/AdminLayout";

const customers = [
  { id: "1", name: "أحمد محمد", email: "ahmed@email.com", orders: 5, totalSpent: 3240, joinDate: "2026-01-15" },
  { id: "2", name: "سارة علي", email: "sara@email.com", orders: 3, totalSpent: 2100, joinDate: "2026-02-01" },
  { id: "3", name: "محمود حسن", email: "mahmoud@email.com", orders: 8, totalSpent: 5670, joinDate: "2025-12-20" },
  { id: "4", name: "فاطمة يوسف", email: "fatma@email.com", orders: 2, totalSpent: 899, joinDate: "2026-02-14" },
  { id: "5", name: "عمر خالد", email: "omar@email.com", orders: 4, totalSpent: 1890, joinDate: "2026-01-28" },
  { id: "6", name: "نورا أشرف", email: "nora@email.com", orders: 6, totalSpent: 4230, joinDate: "2025-11-10" },
];

const AdminCustomers = () => (
  <AdminLayout>
    <h1 className="text-2xl font-bold mb-6">العملاء المسجلين ({customers.length})</h1>

    <div className="bg-card rounded-lg border border-border overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-border text-muted-foreground">
            <th className="text-right p-3">العميل</th>
            <th className="text-right p-3">البريد الإلكتروني</th>
            <th className="text-right p-3">عدد الطلبات</th>
            <th className="text-right p-3">إجمالي المشتريات</th>
            <th className="text-right p-3">تاريخ التسجيل</th>
          </tr>
        </thead>
        <tbody>
          {customers.map(c => (
            <tr key={c.id} className="border-b border-border hover:bg-muted/50">
              <td className="p-3 font-semibold">{c.name}</td>
              <td className="p-3 text-muted-foreground">{c.email}</td>
              <td className="p-3">{c.orders}</td>
              <td className="p-3 font-semibold">{c.totalSpent.toLocaleString()} ج.م</td>
              <td className="p-3 text-muted-foreground">{c.joinDate}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </AdminLayout>
);

export default AdminCustomers;
