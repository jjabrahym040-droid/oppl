import AdminLayout from "@/components/admin/AdminLayout";
import { useEffect, useState } from "react";
import { Plus, Edit, Trash2, X } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

interface Cat { id: string; name: string; icon: string | null; image: string | null; sort_order: number; }

const AdminCategories = () => {
  const [cats, setCats] = useState<Cat[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState({ id: "", name: "", icon: "📦", image: "" });

  const load = async () => {
    const { data } = await supabase.from("categories").select("*").order("sort_order");
    setCats((data || []) as Cat[]);
  };

  useEffect(() => {
    load();
    const ch = supabase.channel("admin-cats")
      .on("postgres_changes", { event: "*", schema: "public", table: "categories" }, load)
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim()) { toast.error("يرجى إدخال اسم التصنيف"); return; }

    if (editId) {
      const { error } = await supabase.from("categories").update({
        name: form.name, icon: form.icon, image: form.image || null,
      }).eq("id", editId);
      if (error) return toast.error(error.message);
      toast.success("تم تعديل التصنيف");
    } else {
      const id = form.id.trim() || `cat-${Date.now()}`;
      const { error } = await supabase.from("categories").insert({
        id, name: form.name, icon: form.icon, image: form.image || null,
        sort_order: cats.length + 1,
      });
      if (error) return toast.error(error.message);
      toast.success("تم إضافة التصنيف");
    }
    setShowForm(false); setEditId(null); setForm({ id: "", name: "", icon: "📦", image: "" });
  };

  const handleDelete = async (id: string) => {
    if (!confirm("حذف التصنيف؟")) return;
    const { error } = await supabase.from("categories").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("تم حذف التصنيف");
  };

  return (
    <AdminLayout>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-black text-[#0A1F44]">إدارة التصنيفات ({cats.length})</h1>
        <button onClick={() => { setEditId(null); setForm({ id: "", name: "", icon: "📦", image: "" }); setShowForm(true); }}
          className="px-4 py-2 font-black text-white rounded-lg flex items-center gap-2"
          style={{ background: 'linear-gradient(135deg, #0A1F44, #1565C0)' }}>
          <Plus className="w-4 h-4" /> إضافة تصنيف
        </button>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 max-w-sm w-full">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-black text-[#0A1F44]">{editId ? "تعديل التصنيف" : "تصنيف جديد"}</h2>
              <button onClick={() => setShowForm(false)}><X className="w-5 h-5" /></button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-3">
              {!editId && (
                <div>
                  <label className="text-xs font-black block mb-1">المعرّف (ID فريد، إنجليزي)</label>
                  <input value={form.id} onChange={e => setForm(f => ({ ...f, id: e.target.value }))} className="w-full px-3 py-2 border-2 rounded-lg text-sm font-bold" placeholder="مثال: phones" />
                </div>
              )}
              <div>
                <label className="text-xs font-black block mb-1">اسم التصنيف</label>
                <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} className="w-full px-3 py-2 border-2 rounded-lg text-sm font-bold" />
              </div>
              <div>
                <label className="text-xs font-black block mb-1">أيقونة (إيموجي)</label>
                <input value={form.icon} onChange={e => setForm(f => ({ ...f, icon: e.target.value }))} className="w-full px-3 py-2 border-2 rounded-lg text-sm" />
              </div>
              <div>
                <label className="text-xs font-black block mb-1">رابط الصورة (اختياري)</label>
                <input value={form.image} onChange={e => setForm(f => ({ ...f, image: e.target.value }))} className="w-full px-3 py-2 border-2 rounded-lg text-sm" placeholder="https://..." />
              </div>
              <button type="submit" className="w-full py-2.5 font-black text-white rounded-lg" style={{ background: 'linear-gradient(135deg, #0A1F44, #E53935)' }}>حفظ</button>
            </form>
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {cats.map(cat => (
          <div key={cat.id} className="bg-white rounded-xl border-2 border-[#eee] p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="text-2xl">{cat.icon || "📦"}</span>
              <span className="font-black text-sm">{cat.name}</span>
            </div>
            <div className="flex items-center gap-1">
              <button onClick={() => { setEditId(cat.id); setForm({ id: cat.id, name: cat.name, icon: cat.icon || "📦", image: cat.image || "" }); setShowForm(true); }} className="text-[#0A1F44]"><Edit className="w-4 h-4" /></button>
              <button onClick={() => handleDelete(cat.id)} className="text-red-600"><Trash2 className="w-4 h-4" /></button>
            </div>
          </div>
        ))}
      </div>
    </AdminLayout>
  );
};

export default AdminCategories;
