import { ChevronLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";

const CheckoutHeader = ({ title, onBack }: { title: string; onBack?: () => void }) => {
  const navigate = useNavigate();
  return (
    <div className="sticky top-0 z-40 bg-white px-4 flex items-center" style={{ height: 52, borderBottom: "1px solid #ECECEC" }}>
      <button onClick={() => (onBack ? onBack() : navigate(-1))} aria-label="Back">
        <ChevronLeft className="w-6 h-6 text-[#111]" strokeWidth={2} />
      </button>
      <h1 className="text-[17px] font-semibold flex-1 text-[#111] ml-2">{title}</h1>
    </div>
  );
};

export default CheckoutHeader;
