import { useState } from "react";
import { Link } from "react-router-dom";
import { Star, Flame } from "lucide-react";
import type { Product } from "@/data/products";
import { useCurrency } from "@/contexts/CurrencyContext";
import RatingModal from "./RatingModal";

interface ProductCardProps { product: Product; }

const formatSold = (n: number) => {
  if (n >= 10000) return `${Math.floor(n / 1000)}K+`;
  if (n >= 1000) return `${(n / 1000).toFixed(1)}K+`;
  return `${n}`;
};

const Stars = ({ value }: { value: number }) => {
  const v = Math.max(0, Math.min(5, value));
  return (
    <div className="flex items-center gap-[1px]" aria-label={`Rating ${v.toFixed(1)} of 5`}>
      {Array.from({ length: 5 }).map((_, i) => {
        const filled = i < Math.round(v);
        return (
          <Star
            key={i}
            className="w-[13px] h-[13px]"
            fill={filled ? "#0B0B0B" : "transparent"}
            stroke="#0B0B0B"
            strokeWidth={1.5}
          />
        );
      })}
    </div>
  );
};

const ProductCard = ({ product }: ProductCardProps) => {
  const { format } = useCurrency();
  const [openRate, setOpenRate] = useState(false);
  const hasDiscount = product.originalPrice && product.originalPrice > product.price;

  return (
    <>
      <Link to={`/product/${product.id}`} className="block group">
        {/* Open, borderless image — taller hero (3:4) */}
        <div className="relative w-full overflow-hidden rounded-xl" style={{ aspectRatio: "3 / 4" }}>
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.02]"
            loading="lazy"
            decoding="async"
          />
          {product.isSuperDeal && (
            <span className="absolute top-2 left-2 bg-[#FF6000] text-white text-[10px] font-bold px-2 py-0.5 rounded-md">
              SUPER DEAL
            </span>
          )}
          <button
            onClick={(e) => { e.preventDefault(); e.stopPropagation(); setOpenRate(true); }}
            className="absolute top-2 right-2 w-8 h-8 rounded-full bg-white/95 shadow-sm flex items-center justify-center hover:bg-white transition-colors"
            aria-label="Rate this product"
          >
            <Star className="w-4 h-4 text-[#FFC107]" fill="#FFC107" strokeWidth={1.4} />
          </button>
        </div>

        {/* Meta */}
        <div className="pt-2.5 px-0.5 flex flex-col gap-1.5">
          <h3 className="text-[14px] leading-[1.3] text-[#111] font-medium line-clamp-2 min-h-[36px]">
            {product.name}
          </h3>

          {/* Price — large, bold, orange */}
          <div className="flex items-baseline gap-1.5" dir="ltr">
            <span className="text-[20px] font-extrabold text-[#FF6000] leading-none tracking-tight">
              {format(product.price)}
            </span>
            {hasDiscount && (
              <span className="text-[12px] text-[#999] line-through">
                {format(product.originalPrice as number)}
              </span>
            )}
          </div>

          {/* Stars + sold */}
          <div className="flex items-center justify-between text-[11px] text-[#666]">
            <div className="flex items-center gap-1">
              <Stars value={Number(product.rating)} />
              {product.reviewCount > 0 && (
                <span className="text-[#999] ml-0.5">({product.reviewCount})</span>
              )}
            </div>
            {product.soldCount > 0 && (
              <span className="flex items-center gap-1 text-[#666]">
                <Flame className="w-3 h-3 text-[#FF6000]" fill="#FF6000" strokeWidth={0} />
                {formatSold(product.soldCount)} sold
              </span>
            )}
          </div>
        </div>
      </Link>

      {openRate && (
        <RatingModal
          productId={product.id}
          productName={product.name}
          productImage={product.image}
          onClose={() => setOpenRate(false)}
        />
      )}
    </>
  );
};

export default ProductCard;
