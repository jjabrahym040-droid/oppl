import { useNavigate } from "react-router-dom";
import { Search, MapPin, ChevronDown, ShoppingCart, User } from "lucide-react";
import CategoryNav from "./CategoryNav";
import { useState } from "react";
import { Link } from "react-router-dom";
import { useCurrency } from "@/contexts/CurrencyContext";
import { useCart } from "@/contexts/CartContext";

const StoreHeader = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const navigate = useNavigate();
  const { country } = useCurrency();
  const { totalItems } = useCart();
  const [openCountry, setOpenCountry] = useState(false);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/products?search=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  return (
    <header className="sticky top-0 z-50 bg-white" style={{ borderBottom: "1px solid var(--border-soft)" }}>
      {/* Top row: brand + icons */}
      <div className="flex items-center justify-between px-4" style={{ height: 48 }}>
        <Link to="/" className="text-[15px] font-semibold tracking-tight text-[#0A1F44]">
          ULTRA-X <span className="text-[#E53935]">STORE</span>
        </Link>
        <div className="flex items-center" style={{ gap: 16 }}>
          <button onClick={() => setOpenCountry(true)} className="flex items-center gap-1 text-[12px] text-[var(--text-2)]">
            <MapPin className="w-3.5 h-3.5" strokeWidth={1.6} />
            <span>{country.code}</span>
            <ChevronDown className="w-3 h-3" strokeWidth={2} />
          </button>
          <Link to="/cart" className="relative">
            <ShoppingCart className="w-5 h-5 text-[var(--text-1)]" strokeWidth={1.6} />
            {totalItems > 0 && (
              <span className="absolute -top-1.5 -right-2 bg-[#FF6000] text-white text-[10px] font-medium rounded-full min-w-[16px] h-[16px] px-1 flex items-center justify-center">
                {totalItems}
              </span>
            )}
          </Link>
          <Link to="/account">
            <User className="w-5 h-5 text-[var(--text-1)]" strokeWidth={1.6} />
          </Link>
        </div>
      </div>

      {/* Search row — black pill */}
      <div className="px-3 pb-2.5">
        <form onSubmit={handleSearch} className="flex items-center" style={{ height: 44, borderRadius: 999, background: "#0B0B0B", paddingLeft: 16, paddingRight: 4 }}>
          <Search className="w-[18px] h-[18px] text-white flex-shrink-0" strokeWidth={2} />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search anything..."
            className="flex-1 px-3 bg-transparent text-[14px] text-white placeholder:text-[#9a9a9a] outline-none"
          />
          <button type="submit" className="text-[13px] font-semibold text-[#0B0B0B] px-5 h-[36px] rounded-full bg-white">
            Go
          </button>
        </form>
      </div>

      <CategoryNav />

      {openCountry && <CountryModal onClose={() => setOpenCountry(false)} />}
    </header>
  );
};

const CountryModal = ({ onClose }: { onClose: () => void }) => {
  const { country, setCountry, countries } = useCurrency();
  const [query, setQuery] = useState("");
  const filtered = countries.filter(c =>
    c.name.toLowerCase().includes(query.toLowerCase()) || c.currency.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div onClick={onClose} className="fixed inset-0 z-[100] bg-black/40 flex items-end sm:items-center justify-center">
      <div onClick={e => e.stopPropagation()} className="bg-white w-full sm:max-w-md sm:rounded-xl rounded-t-2xl max-h-[85vh] flex flex-col overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3" style={{ borderBottom: "1px solid var(--border-soft)" }}>
          <h2 className="text-[15px] font-medium text-[var(--text-1)]">Deliver to</h2>
          <button onClick={onClose} className="text-[var(--text-2)] text-xl leading-none">×</button>
        </div>
        <div className="px-4 py-3" style={{ borderBottom: "1px solid var(--border-soft)" }}>
          <div className="flex items-center gap-2 px-3" style={{ height: 40, border: "1px solid var(--border-soft)", borderRadius: 12 }}>
            <Search className="w-4 h-4 text-[var(--text-3)]" />
            <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search country..." className="flex-1 bg-transparent text-sm outline-none placeholder:text-[var(--text-3)]" />
          </div>
        </div>
        <div className="flex-1 overflow-y-auto">
          {filtered.map(c => (
            <button key={c.code} onClick={() => { setCountry(c); onClose(); }} className="w-full flex items-center justify-between px-4 py-3 hover:bg-[#fafafa]" style={{ borderBottom: "1px solid #f5f5f5" }}>
              <div className="flex items-center gap-3">
                <span className="text-2xl">{c.flag}</span>
                <div className="text-left">
                  <div className="text-sm text-[var(--text-1)]">{c.name}</div>
                  <div className="text-[11px] text-[var(--text-2)]">{c.currency} · {c.symbol}</div>
                </div>
              </div>
              {country.code === c.code && <span className="text-[#FF6000]">✓</span>}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default StoreHeader;
