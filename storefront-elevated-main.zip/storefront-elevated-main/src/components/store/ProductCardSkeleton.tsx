const ProductCardSkeleton = () => (
  <div className="bg-white animate-pulse">
    <div className="aspect-square bg-[#eee]" />
    <div className="px-2 pt-2 pb-3 space-y-1.5">
      <div className="h-5 bg-[#eee] rounded w-2/3" />
      <div className="h-3 bg-[#f0f0f0] rounded w-full" />
      <div className="h-3 bg-[#f0f0f0] rounded w-1/2" />
    </div>
  </div>
);

export default ProductCardSkeleton;
