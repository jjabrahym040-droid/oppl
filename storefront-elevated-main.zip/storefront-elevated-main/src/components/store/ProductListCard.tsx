import { Link } from "react-router-dom";
import type { Product } from "@/data/products";
import { useCurrency } from "@/contexts/CurrencyContext";

interface Props { product: Product; }

const formatNum = (n: number) => {
  if (n >= 10000) return `${Math.floor(n / 1000)}K+`;
  if (n >= 1000) return `${(n / 1000).toFixed(1)}K+`;
  return `${n}`;
};

const ProductListCard = ({ product }: Props) => {
  const { format } = useCurrency();
  const hasDiscount = product.originalPrice && product.originalPrice > product.price;
  const watching = Math.max(3, Math.min(99, Math.round((product.reviewCount || 10) / 4)));

  return (
    <Link
      to={`/product/${product.id}`}
      className="flex gap-3 px-4 py-4 bg-white border-b border-[#f0f0f0] active:bg-[#fafafa] transition-colors"
    >
      {/* Square image — left */}
      <div className="flex-shrink-0 w-[132px] h-[132px] rounded-lg overflow-hidden bg-[#f7f7f7]">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover"
          loading="lazy"
          decoding="async"
        />
      </div>

      {/* Details — right */}
      <div className="flex-1 min-w-0 flex flex-col gap-1">
        {product.isSuperDeal && (
          <span className="text-[10px] font-bold text-[#E53935] tracking-wide">NEW LISTING</span>
        )}
        <h3 className="text-[14px] leading-[1.35] text-[#111] font-normal line-clamp-3">
          {product.name}
        </h3>
        <p className="text-[12px] text-[#888]">Brand New{product.brand ? ` · ${product.brand}` : ""}</p>

        <div className="mt-1 flex items-baseline gap-2" dir="ltr">
          <span className="text-[18px] font-bold text-[#111] leading-none">
            {format(product.price)}
          </span>
          {hasDiscount && (
            <span className="text-[12px] text-[#999] line-through">
              {format(product.originalPrice as number)}
            </span>
          )}
        </div>

        <p className="text-[12px] text-[#888]">Free shipping</p>

        <div className="flex items-center gap-3 text-[12px] mt-0.5">
          {product.soldCount > 0 && (
            <span className="text-[#E53935] font-medium">{formatNum(product.soldCount)} sold</span>
          )}
          <span className="text-[#E53935] font-medium">{watching} watching</span>
        </div>
      </div>
    </Link>
  );
};

export default ProductListCard;
