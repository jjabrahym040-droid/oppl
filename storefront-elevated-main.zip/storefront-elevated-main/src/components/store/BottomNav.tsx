import { Link, useLocation } from "react-router-dom";
import { Home, Search, ShoppingCart, User, Check, Truck } from "lucide-react";
import { useCart } from "@/contexts/CartContext";

const ROYAL_BLUE = "#0A1F44";
const BLACK = "#0B0B0B";

const BottomNav = () => {
  const location = useLocation();
  const { totalItems } = useCart();
  const path = location.pathname;

  const items = [
    { to: "/", icon: Home, label: "Home", match: "/" },
    { to: "/products", icon: Search, label: "Shop", match: "/products" },
    { to: "/cart", icon: ShoppingCart, label: "Cart", match: "/cart", badge: totalItems },
    { to: "/track", icon: Truck, label: "Track", match: "/track" },
    { to: "/account", icon: User, label: "Account", match: "/account" },
  ];

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-white border-t safe-area-bottom" style={{ borderColor: "#ECECEC" }}>
      <div className="flex items-center justify-around py-0.5">
        {items.map(item => {
          const active = item.match === "/" ? path === "/" : path.startsWith(item.match);
          const activeColor = "#FF6000";
          return (
            <Link key={item.to} to={item.to} className="flex flex-col items-center gap-0.5 relative min-w-[52px] py-1.5">
              {active && <span className="absolute top-0 left-1/2 -translate-x-1/2 w-8 h-[2px] rounded-full" style={{ backgroundColor: activeColor }} />}
              <div className="relative">
                <item.icon
                  className="w-[22px] h-[22px]"
                  strokeWidth={active ? 2.25 : 1.75}
                  style={{ color: active ? activeColor : BLACK }}
                />
                {item.badge && item.badge > 0 && (
                  <span className="absolute -top-1.5 -right-2 text-[9px] font-bold rounded-full min-w-[14px] h-[14px] px-1 flex items-center justify-center text-white" style={{ backgroundColor: "#FF6000" }}>
                    {item.badge}
                  </span>
                )}
              </div>
              <span className="text-[10px] font-medium leading-none" style={{ color: active ? activeColor : BLACK }}>
                {item.label}
              </span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
};

export default BottomNav;
