import { ShieldCheck, PackageCheck } from "lucide-react";

const CheckoutProtectionBanner = () => (
  <div className="w-full bg-gradient-to-r from-[#FFF4E6] to-[#FFE9D6] px-4 py-3 flex items-center gap-3 border-b border-[#F0D9B8]">
    <div className="relative w-10 h-10 rounded-full bg-white flex items-center justify-center flex-shrink-0 shadow-sm">
      <PackageCheck className="w-5 h-5 text-[#FF6000]" strokeWidth={2} />
      <span className="absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full bg-[#1B873F] flex items-center justify-center ring-2 ring-white">
        <ShieldCheck className="w-2.5 h-2.5 text-white" strokeWidth={3} />
      </span>
    </div>
    <div className="flex-1 min-w-0">
      <div className="text-[13px] font-semibold text-[#111] leading-tight">Protected by ShopZone Secure</div>
      <div className="text-[11px] text-[#666] mt-0.5 leading-tight">Encrypted checkout · Buyer protection on every order</div>
    </div>
    <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-white border border-[#F0D9B8]">
      <span className="w-1.5 h-1.5 rounded-full bg-[#1B873F] animate-pulse" />
      <span className="text-[10px] font-medium text-[#1B873F]">SECURE</span>
    </div>
  </div>
);

export default CheckoutProtectionBanner;
