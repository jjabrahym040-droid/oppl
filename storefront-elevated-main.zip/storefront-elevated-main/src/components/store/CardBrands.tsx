// High-fidelity inline SVG payment brand icons. Vector — stays sharp at any size.

export const VisaIcon = ({ h = 22 }: { h?: number }) => (
  <svg height={h} viewBox="0 0 48 32" xmlns="http://www.w3.org/2000/svg" aria-label="Visa">
    <rect width="48" height="32" rx="4" fill="#fff" stroke="#E5E7EB" />
    <path d="M19.4 21.1l1.7-10.2h2.7l-1.7 10.2h-2.7zm12.4-9.95c-.55-.21-1.4-.43-2.46-.43-2.7 0-4.6 1.4-4.62 3.4-.02 1.48 1.36 2.3 2.4 2.79 1.07.5 1.43.83 1.43 1.28-.01.69-.84 1-1.62 1-1.08 0-1.66-.16-2.55-.54l-.35-.16-.38 2.3c.63.28 1.8.53 3.01.55 2.86 0 4.73-1.38 4.75-3.52.01-1.18-.72-2.07-2.3-2.8-.96-.47-1.55-.79-1.55-1.27 0-.43.5-.88 1.58-.88.9-.02 1.55.18 2.06.4l.25.12.35-2.24zm6.95-.25h-2.1c-.65 0-1.14.18-1.42.85l-4.04 9.35h2.86l.57-1.55h3.49l.33 1.55h2.52L37.75 10.9zm-3.36 6.61c.22-.58 1.08-2.86 1.08-2.86-.02.03.22-.6.36-.99l.18.9s.52 2.45.63 2.95h-2.25zM17.18 10.9l-2.66 6.96-.28-1.42c-.5-1.64-2.05-3.42-3.78-4.31l2.43 8.97h2.88l4.28-10.2h-2.87z" fill="#1A1F71" />
    <path d="M11.96 10.9H7.59l-.04.21c3.4.85 5.66 2.92 6.6 5.41l-.95-4.76c-.16-.65-.64-.84-1.24-.86z" fill="#F7B600" />
  </svg>
);

export const MastercardIcon = ({ h = 22 }: { h?: number }) => (
  <svg height={h} viewBox="0 0 48 32" xmlns="http://www.w3.org/2000/svg" aria-label="Mastercard">
    <rect width="48" height="32" rx="4" fill="#fff" stroke="#E5E7EB" />
    <circle cx="20" cy="16" r="7" fill="#EB001B" />
    <circle cx="28" cy="16" r="7" fill="#F79E1B" />
    <path d="M24 10.6a7 7 0 010 10.8 7 7 0 010-10.8z" fill="#FF5F00" />
  </svg>
);

export const AmexIcon = ({ h = 22 }: { h?: number }) => (
  <svg height={h} viewBox="0 0 48 32" xmlns="http://www.w3.org/2000/svg" aria-label="American Express">
    <rect width="48" height="32" rx="4" fill="#1F72CD" />
    <text x="24" y="14.5" textAnchor="middle" fontFamily="Arial, sans-serif" fontWeight="900" fontSize="6.4" fill="#fff" letterSpacing="0.3">AMERICAN</text>
    <text x="24" y="22.5" textAnchor="middle" fontFamily="Arial, sans-serif" fontWeight="900" fontSize="6.4" fill="#fff" letterSpacing="0.3">EXPRESS</text>
  </svg>
);

export const JcbIcon = ({ h = 22 }: { h?: number }) => (
  <svg height={h} viewBox="0 0 48 32" xmlns="http://www.w3.org/2000/svg" aria-label="JCB">
    <rect width="48" height="32" rx="4" fill="#fff" stroke="#E5E7EB" />
    <rect x="8" y="8" width="9.5" height="16" rx="2" fill="#0E4C96" />
    <rect x="19.25" y="8" width="9.5" height="16" rx="2" fill="#C8102E" />
    <rect x="30.5" y="8" width="9.5" height="16" rx="2" fill="#00A752" />
    <text x="24" y="20" textAnchor="middle" fontFamily="Arial, sans-serif" fontWeight="900" fontSize="8" fill="#fff">JCB</text>
  </svg>
);

export const CardBrandsRow = ({ h = 22, showFullList = true, onFullList }: { h?: number; showFullList?: boolean; onFullList?: () => void }) => (
  <div className="flex items-center" style={{ gap: 8 }}>
    <VisaIcon h={h} />
    <MastercardIcon h={h} />
    <AmexIcon h={h} />
    <JcbIcon h={h} />
    {showFullList && (
      <button type="button" onClick={onFullList} className="flex items-center gap-0.5 text-[12px] text-[#666] px-2 py-1 rounded-md hover:bg-[#F2F2F2]">
        Full List
        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M9 6l6 6-6 6"/></svg>
      </button>
    )}
  </div>
);
