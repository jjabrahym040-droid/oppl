import { Loader2, ShieldCheck } from "lucide-react";

const CheckoutLoadingOverlay = ({ label = "Verifying secure connection..." }: { label?: string }) => (
  <div className="fixed inset-0 z-[100] bg-white/95 backdrop-blur-sm flex flex-col items-center justify-center">
    <div className="relative">
      <Loader2 className="w-14 h-14 text-[#FF6000] animate-spin" strokeWidth={1.6} />
      <ShieldCheck className="w-6 h-6 text-[#1B873F] absolute inset-0 m-auto" strokeWidth={2.2} />
    </div>
    <div className="mt-5 text-[13.5px] text-[#111] font-medium">{label}</div>
    <div className="mt-1 text-[11.5px] text-[#666]">Please wait a moment</div>
  </div>
);

export default CheckoutLoadingOverlay;
