import { Link } from "react-router-dom";

const StoreFooter = () => (
  <footer className="hidden md:block bg-card border-t border-border py-3 px-4">
    <div className="container mx-auto">
      <div className="grid grid-cols-3 gap-4 text-xs">
        <div>
          <h4 className="font-semibold mb-1.5 text-foreground">About</h4>
          <ul className="space-y-1 text-muted-foreground">
            <li><Link to="/" className="hover:text-primary">About us</Link></li>
            <li><Link to="/" className="hover:text-primary">Contact</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold mb-1.5 text-foreground">Customer Service</h4>
          <ul className="space-y-1 text-muted-foreground">
            <li><Link to="/" className="hover:text-primary">Returns & refunds</Link></li>
            <li><Link to="/" className="hover:text-primary">Privacy & security</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold mb-1.5 text-foreground">Account</h4>
          <ul className="space-y-1 text-muted-foreground">
            <li><Link to="/account" className="hover:text-primary">Orders</Link></li>
            <li><Link to="/cart" className="hover:text-primary">Cart</Link></li>
            <li><Link to="/settings" className="hover:text-primary">Settings</Link></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border mt-3 pt-2 text-center text-[10px] text-muted-foreground">
        © 2026 ULTRA-X STORE — All rights reserved
      </div>
    </div>
  </footer>
);

export default StoreFooter;
