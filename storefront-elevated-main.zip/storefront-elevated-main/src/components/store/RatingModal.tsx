import { useState } from "react";
import { Star, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { useNavigate } from "react-router-dom";

interface Props {
  productId: string;
  productName: string;
  productImage: string;
  onClose: () => void;
}

const RatingModal = ({ productId, productName, productImage, onClose }: Props) => {
  const [rating, setRating] = useState(0);
  const [hover, setHover] = useState(0);
  const [comment, setComment] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  const submit = async () => {
    if (!user) {
      toast({ title: "Sign in required", description: "Please sign in to rate this product." });
      onClose();
      navigate("/auth");
      return;
    }
    if (rating === 0) {
      toast({ title: "Pick a rating", description: "Tap a star to rate." });
      return;
    }
    setSubmitting(true);
    const { error } = await supabase
      .from("product_reviews")
      .upsert(
        { product_id: productId, user_id: user.id, rating, comment: comment.trim() || null },
        { onConflict: "product_id,user_id" }
      );
    setSubmitting(false);
    if (error) {
      toast({ title: "Could not save", description: error.message, variant: "destructive" });
      return;
    }
    toast({ title: "Thanks for your review!", description: `You rated this ${rating}/5.` });
    onClose();
  };

  return (
    <div onClick={onClose} className="fixed inset-0 z-[200] bg-black/50 flex items-end sm:items-center justify-center">
      <div onClick={(e) => e.stopPropagation()} className="bg-white w-full sm:max-w-md sm:rounded-2xl rounded-t-3xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-[#eee]">
          <h2 className="text-[15px] font-semibold text-[#111]">Rate this product</h2>
          <button onClick={onClose} aria-label="close"><X className="w-5 h-5 text-[#666]" /></button>
        </div>

        <div className="px-5 py-4 flex items-center gap-3 border-b border-[#f3f3f3]">
          <img src={productImage} alt="" className="w-14 h-14 rounded-lg object-cover bg-[#f5f5f5]" />
          <p className="text-[13px] text-[#222] line-clamp-2 flex-1">{productName}</p>
        </div>

        <div className="px-5 py-5 flex flex-col items-center gap-3">
          <div className="flex items-center gap-1">
            {[1, 2, 3, 4, 5].map((n) => {
              const active = (hover || rating) >= n;
              return (
                <button
                  key={n}
                  type="button"
                  onMouseEnter={() => setHover(n)}
                  onMouseLeave={() => setHover(0)}
                  onClick={() => setRating(n)}
                  className="p-1"
                  aria-label={`${n} star${n > 1 ? "s" : ""}`}
                >
                  <Star
                    className="w-9 h-9 transition-transform"
                    fill={active ? "#FFC107" : "transparent"}
                    stroke={active ? "#FFC107" : "#bbb"}
                    strokeWidth={1.5}
                  />
                </button>
              );
            })}
          </div>
          <p className="text-[12px] text-[#666] h-4">
            {rating === 0 ? "Tap a star to rate" : ["", "Poor", "Fair", "Good", "Very good", "Excellent"][rating]}
          </p>
        </div>

        <div className="px-5 pb-4">
          <textarea
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            placeholder="Write your comment (optional)…"
            rows={4}
            className="w-full text-[13px] text-[#111] placeholder:text-[#999] bg-[#fafafa] border border-[#ececec] rounded-xl p-3 outline-none focus:border-[#FF6000] resize-none"
          />
        </div>

        <div className="px-5 pb-5">
          <button
            onClick={submit}
            disabled={submitting}
            className="w-full h-12 rounded-xl text-white font-semibold text-[14px] disabled:opacity-60"
            style={{ background: "linear-gradient(90deg,#FF6000,#E53935)" }}
          >
            {submitting ? "Submitting…" : "Submit Review"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default RatingModal;
