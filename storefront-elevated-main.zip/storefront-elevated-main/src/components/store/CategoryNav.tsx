import { Link, useLocation, useSearchParams, useNavigate } from "react-router-dom";
import { useCategories } from "@/hooks/useProducts";

const CategoryNav = () => {
  const categories = useCategories();
  const location = useLocation();
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const onHome = location.pathname === "/";
  const onProducts = location.pathname.startsWith("/products");
  const activeCat = onHome ? params.get("cat") : (onProducts ? params.get("category") : null);
  const isAll = !activeCat;

  if (categories.length === 0) return null;
  if (!onHome) return null; // Home-only category bar

  const itemCls = "flex-shrink-0 px-3 py-2 text-[13px] font-medium relative whitespace-nowrap";

  const setHomeCat = (id: string | null) => {
    const next = new URLSearchParams(params);
    if (id) next.set("cat", id); else next.delete("cat");
    navigate({ pathname: "/", search: next.toString() ? `?${next}` : "" }, { replace: true });
  };

  return (
    <nav className="bg-white border-b border-[var(--border-soft)]">
      <div className="flex overflow-x-auto hide-scrollbar px-2">
        {onHome ? (
          <button onClick={() => setHomeCat(null)} className={itemCls} style={{ color: isAll ? "#E53935" : "#555" }}>
            All
            {isAll && <span className="absolute left-3 right-3 bottom-0 h-[2px] bg-[#E53935] rounded-full" />}
          </button>
        ) : (
          <Link to="/" className={itemCls} style={{ color: isAll ? "#E53935" : "#555" }}>
            All
            {isAll && <span className="absolute left-3 right-3 bottom-0 h-[2px] bg-[#E53935] rounded-full" />}
          </Link>
        )}
        {categories.map(c => {
          const active = activeCat === c.id;
          const color = active ? "#E53935" : "#555";
          if (onHome) {
            return (
              <button key={c.id} onClick={() => setHomeCat(c.id)} className={itemCls} style={{ color }}>
                {c.name}
                {active && <span className="absolute left-3 right-3 bottom-0 h-[2px] bg-[#E53935] rounded-full" />}
              </button>
            );
          }
          return (
            <Link key={c.id} to={`/products?category=${c.id}`} className={itemCls} style={{ color }}>
              {c.name}
              {active && <span className="absolute left-3 right-3 bottom-0 h-[2px] bg-[#E53935] rounded-full" />}
            </Link>
          );
        })}
      </div>
    </nav>
  );
};

export default CategoryNav;
