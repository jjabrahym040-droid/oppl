
# Implementation Plan

## 1. eBay Import — Fix `auth.getClaims is not a function`

**Diagnosis:** The deployed `@supabase/supabase-js` version pinned in the edge function (`@2.45.0`) does not expose `getClaims()` on the auth client. That method ships in **v2.49+**. The runtime therefore throws `TypeError: userClient.auth.getClaims is not a function`, which the catch block converts into the generic non-2xx error the user sees.

**Fix:**
1. Bump the SDK import in `supabase/functions/ebay-import/index.ts` from `@supabase/supabase-js@2.45.0` → `@2.57.4` (stable, supports `getClaims`).
2. Keep the JWT verification using `getClaims(token)` — it's the recommended path.
3. Fallback safety: if `getClaims` is unavailable, decode `sub` from the JWT payload directly (defensive).

**eBay Browse API flow (already correct, just re-verifying):**
- Pull `EBAY_CLIENT_ID` / `EBAY_CLIENT_SECRET` from Deno.env.
- POST to `https://api.ebay.com/identity/v1/oauth2/token` with `grant_type=client_credentials` + scope `https://api.ebay.com/oauth/api_scope` → application access token (cached 60 s before exp).
- Extract legacy item ID from URL (`/itm/...`, `?item=...`, etc.).
- GET `https://api.ebay.com/buy/browse/v1/item/get_item_by_legacy_id?legacy_item_id={id}` with `Authorization: Bearer <token>` and `X-EBAY-C-MARKETPLACE-ID: EBAY_US`.
- Map response → `{ name: title, description: shortDescription||description (HTML stripped), price: price.value, images: [image.imageUrl, ...additionalImages] (upgraded to s-l1600), brand, features: localizedAspects }`.
- Re-host every image to the `product-images` bucket and return public URLs so admin form fills `name / description / price / thumbnail / gallery`.

**Error surfacing:** All failures already return `200 { ok:false, error }` (done last turn) so the toast in `AdminProducts.tsx` shows the real reason instead of "non-2xx".

## 2. UI / UX — Open Fluid Product Grid

**Card (`ProductCard.tsx`):**
- Remove ALL container backgrounds/borders around the image (no `bg-[#f7f7f7]`, no border, no shadow). Already removed last turn — verify on Shop page too.
- Image: full-width, `aspect-[3/4]` (taller, hero-style like Temu/TikTok Shop), `rounded-xl`, `object-cover`. Larger visual footprint = images dominate.
- Below image, vertical stack with comfortable padding:
  - **Title**: 2-line clamp, `text-[14px]`, `font-medium`, color `#111`, leading-snug. Stronger than current `font-normal`.
  - **Stars row**: solid black 5-star bar (filled per rating value), `w-3.5 h-3.5`, gap-0.5; muted "(reviewCount)" in `#999` next to it.
  - **Price row**: orange `#FF6000`, `text-[20px] font-extrabold`, currency code small next to it; original price strikethrough `#999` if discounted.
  - **Sold row**: 🔥 fire icon (orange, filled) + "12K+ sold" in `#666`, `text-[11px]`.
- Star rating button (top-right): keep current `Star` icon in white circle → opens existing `RatingModal`. No heart anywhere.

**Grid (`Index.tsx` + `Products.tsx`):**
- 2 columns, `column-gap: 10px`, `row-gap: 20px`, `px-3 py-3`, page background pure white.
- Remove sidebar grey strip (`bg-[#f5f5f5]`) inside Products page that creates the "pink/box" feel — switch to white with subtle `#f0f0f0` divider.
- No card wrappers, no per-card backgrounds → "open fluid" feel.

## 3. Bottom Navigation — Slim & HD

**`BottomNav.tsx`:**
- Total height ≈ 52 px (down from ~70 px), `py-1`.
- Icons: bump from 18 px → **22 px** (HD feel) but keep label `text-[10px]`.
- Active state: orange `#FF6000` icon + label, no chunky filled square; thin 2 px top accent bar above active item.
- Inactive: solid black icons, `strokeWidth={1.75}`.
- Border-top: 1 px `#ECECEC` (already done).
- `StoreLayout` main padding-bottom = 56 px (matches nav height).

## 4. Home-only Category Bar

- `CategoryNav.tsx` is already mounted in `StoreHeader.tsx`. Wrap its render in `useLocation()` check: only render when `pathname === "/"`.
- On Home, clicking a category sets `?cat=` URL param and filters `Index.tsx` in place (already implemented).
- Shop page (`/products`) keeps its left sidebar category list — fully independent.

## Files to touch

```text
supabase/functions/ebay-import/index.ts   bump SDK to 2.57.4 + JWT fallback
src/components/store/ProductCard.tsx       3:4 image, bigger title, black stars, fire+sold row
src/components/store/BottomNav.tsx         22px icons, 52px height, accent bar
src/components/store/StoreLayout.tsx       pb to 56
src/components/store/CategoryNav.tsx       early-return when not on "/"
src/pages/Products.tsx                     drop grey sidebar bg, white grid
src/pages/Index.tsx                        tighter gap (10/20)
```

No DB migration, no new dependencies, no secret changes.
