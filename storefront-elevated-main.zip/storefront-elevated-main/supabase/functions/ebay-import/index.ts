// eBay product import — fetches item by legacy URL, downloads images to product-images bucket
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const json = (status: number, body: unknown) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

const extractItemId = (input: string): string | null => {
  const trimmed = input.trim();
  if (/^\d{9,}$/.test(trimmed)) return trimmed;
  const m = trimmed.match(/\/itm\/(?:[^/]+\/)?(\d{9,})/i);
  if (m) return m[1];
  const q = trimmed.match(/[?&](?:item|itemid|legacyid)=(\d{9,})/i);
  if (q) return q[1];
  const any = trimmed.match(/(\d{10,})/);
  return any ? any[1] : null;
};

const upgradeImageUrl = (url: string) =>
  url.replace(/\/s-l\d+\./i, "/s-l1600.").replace(/\$_\d+\./i, "$_57.");

let cachedToken: { token: string; exp: number } | null = null;

async function getEbayToken(): Promise<string> {
  if (cachedToken && cachedToken.exp > Date.now() + 60_000) return cachedToken.token;
  const id = Deno.env.get("EBAY_CLIENT_ID");
  const secret = Deno.env.get("EBAY_CLIENT_SECRET");
  if (!id || !secret) throw new Error("EBAY_CLIENT_ID / EBAY_CLIENT_SECRET not configured");
  const basic = btoa(`${id}:${secret}`);
  const res = await fetch("https://api.ebay.com/identity/v1/oauth2/token", {
    method: "POST",
    headers: {
      Authorization: `Basic ${basic}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: "grant_type=client_credentials&scope=https%3A%2F%2Fapi.ebay.com%2Foauth%2Fapi_scope",
  });
  const data = await res.json();
  if (!res.ok) throw new Error(`eBay token failed: ${JSON.stringify(data)}`);
  cachedToken = { token: data.access_token, exp: Date.now() + (data.expires_in ?? 7200) * 1000 };
  return cachedToken.token;
}

async function uploadImage(admin: ReturnType<typeof createClient>, srcUrl: string): Promise<string | null> {
  try {
    const r = await fetch(srcUrl);
    if (!r.ok) return null;
    const buf = new Uint8Array(await r.arrayBuffer());
    const ct = r.headers.get("content-type") || "image/jpeg";
    const ext = ct.includes("png") ? "png" : ct.includes("webp") ? "webp" : "jpg";
    const path = `ebay/${crypto.randomUUID()}.${ext}`;
    const { error } = await admin.storage.from("product-images").upload(path, buf, {
      contentType: ct,
      cacheControl: "3600",
      upsert: false,
    });
    if (error) { console.error("upload err", error); return null; }
    const { data } = admin.storage.from("product-images").getPublicUrl(path);
    return data.publicUrl;
  } catch (e) {
    console.error("img fetch err", e);
    return null;
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    console.log("ebay-import invoked");
    console.log("EBAY_CLIENT_ID present:", !!Deno.env.get("EBAY_CLIENT_ID"));
    console.log("EBAY_CLIENT_SECRET present:", !!Deno.env.get("EBAY_CLIENT_SECRET"));

    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) return json(200, { ok: false, error: "Unauthorized — please sign in as admin" });

    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SUPABASE_ANON = Deno.env.get("SUPABASE_ANON_KEY") || Deno.env.get("SUPABASE_PUBLISHABLE_KEY")!;
    const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const userClient = createClient(SUPABASE_URL, SUPABASE_ANON, {
      global: { headers: { Authorization: authHeader } },
    });
    const token = authHeader.replace("Bearer ", "");
    let userId: string | null = null;
    try {
      // Preferred path (supabase-js >= 2.49)
      const anyAuth = userClient.auth as unknown as { getClaims?: (t: string) => Promise<{ data: { claims?: { sub?: string } } | null; error: unknown }> };
      if (typeof anyAuth.getClaims === "function") {
        const { data: claims } = await anyAuth.getClaims(token);
        userId = claims?.claims?.sub ?? null;
      }
      // Fallback: decode JWT payload directly
      if (!userId) {
        const parts = token.split(".");
        if (parts.length >= 2) {
          const payload = JSON.parse(atob(parts[1].replace(/-/g, "+").replace(/_/g, "/")));
          userId = payload?.sub ?? null;
        }
      }
    } catch (e) {
      console.error("auth decode error:", e);
    }
    if (!userId) return json(200, { ok: false, error: "Unauthorized — invalid session" });

    const admin = createClient(SUPABASE_URL, SERVICE_ROLE);
    const { data: roleRow } = await admin
      .from("user_roles").select("role").eq("user_id", userId).eq("role", "admin").maybeSingle();
    if (!roleRow) return json(200, { ok: false, error: "Admin only" });

    const body = await req.json().catch(() => ({}));
    const url = String(body?.url || "").trim();
    if (!url) return json(200, { ok: false, error: "Missing url" });

    const itemId = extractItemId(url);
    if (!itemId) return json(200, { ok: false, error: "Could not extract eBay Item ID from URL" });
    console.log("Extracted itemId:", itemId);

    let accessToken: string;
    try {
      accessToken = await getEbayToken();
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      console.error("token error:", msg);
      return json(200, { ok: false, error: `eBay auth failed: ${msg}. Verify EBAY_CLIENT_ID and EBAY_CLIENT_SECRET are Production keys.` });
    }

    const epUrl = `https://api.ebay.com/buy/browse/v1/item/get_item_by_legacy_id?legacy_item_id=${itemId}`;
    const itemRes = await fetch(epUrl, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "X-EBAY-C-MARKETPLACE-ID": "EBAY_US",
        Accept: "application/json",
      },
    });
    const item = await itemRes.json();
    if (!itemRes.ok) {
      console.error("eBay API non-ok:", itemRes.status, JSON.stringify(item).slice(0, 500));
      const detail = item?.errors?.[0]?.message || JSON.stringify(item).slice(0, 200);
      return json(200, { ok: false, error: `eBay API ${itemRes.status}: ${detail}` });
    }

    const title: string = item.title || "";
    const description: string = (item.shortDescription || item.description || "")
      .replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim().slice(0, 4000);
    const price = Number(item.price?.value ?? 0);

    const rawImages: string[] = [
      ...(item.image?.imageUrl ? [item.image.imageUrl] : []),
      ...((item.additionalImages || []) as { imageUrl: string }[]).map((i) => i.imageUrl),
    ].filter(Boolean).map(upgradeImageUrl);
    const uniqueImages = Array.from(new Set(rawImages)).slice(0, 12);

    const features: string[] = (item.localizedAspects || [])
      .map((a: { name: string; value: string }) => `${a.name}: ${a.value}`)
      .slice(0, 30);

    // Re-host images in our bucket
    const uploaded: string[] = [];
    for (const u of uniqueImages) {
      const newUrl = await uploadImage(admin, u);
      if (newUrl) uploaded.push(newUrl);
    }

    return json(200, {
      ok: true,
      itemId,
      name: title,
      description,
      price,
      images: uploaded,
      thumbnail: uploaded[0] || null,
      features,
      brand: item.brand || "",
    });
  } catch (e) {
    console.error("ebay-import error", e);
    return json(200, { ok: false, error: e instanceof Error ? e.message : String(e) });
  }
});
